#!/usr/bin/env bash
#
# EC2 Quota Monitor - 卸载脚本
#
#   sudo ./uninstall.sh              # 停服务、删代码，保留数据和配置
#   sudo ./uninstall.sh --purge      # 同时删除数据目录、环境变量文件和系统用户
#
set -euo pipefail

APP_NAME="ec2-quota-monitor"
APP_DIR="${APP_DIR:-/opt/${APP_NAME}}"
DATA_DIR="${DATA_DIR:-/var/lib/${APP_NAME}}"
ETC_DIR="${ETC_DIR:-/etc/${APP_NAME}}"
SERVICE_USER="${SERVICE_USER:-ec2quota}"
UNIT_FILE="/etc/systemd/system/${APP_NAME}.service"

PURGE=0
[[ "${1:-}" == "--purge" ]] && PURGE=1

info() { printf '\033[1;34m[信息]\033[0m %s\n' "$*"; }
ok()   { printf '\033[1;32m[成功]\033[0m %s\n' "$*"; }

[[ $EUID -eq 0 ]] || { echo "请用 root 运行: sudo $0" >&2; exit 1; }

if systemctl list-unit-files | grep -q "^${APP_NAME}.service"; then
  info "停止并禁用服务"
  systemctl disable --now "${APP_NAME}" >/dev/null 2>&1 || true
fi

rm -f "${UNIT_FILE}"
systemctl daemon-reload

info "删除代码目录 ${APP_DIR}"
rm -rf "${APP_DIR}"

if [[ ${PURGE} -eq 1 ]]; then
  info "清除数据目录 ${DATA_DIR}（含 AWS 凭证配置）"
  rm -rf "${DATA_DIR}"
  info "清除配置目录 ${ETC_DIR}"
  rm -rf "${ETC_DIR}"
  if id "${SERVICE_USER}" >/dev/null 2>&1; then
    info "删除系统用户 ${SERVICE_USER}"
    userdel "${SERVICE_USER}" || true
  fi
  ok "已完全卸载"
else
  ok "已卸载，保留了 ${DATA_DIR} 和 ${ETC_DIR}"
  echo "    需要一并删除时执行: sudo $0 --purge"
fi
