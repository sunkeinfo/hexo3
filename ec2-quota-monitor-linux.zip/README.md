# EC2 Quota Monitor (Linux 版)

AWS EC2 配额监控服务 —— 定时检查 EC2 Service Quotas，配额一变化立刻发邮件通知。

Windows 版（NSSM + Flask 开发服务器）的 Ubuntu/Debian 移植版：systemd + gunicorn，
可以在服务器上长期无人值守运行。

## 功能

- 🔄 **定时监控**：默认每 10 分钟检查一次（1–1440 分钟可调，改完立即生效，不用重启）
- 📧 **邮件通知**：配额变化时发送邮件；发送失败会在下一轮重试，不会把变化吞掉
- 🌐 **Web 界面**：配置、启停、查看配额与最近事件
- 🔑 **登录保护**：面向公网访问设计，初始密码 `123`，登录后在界面上改；密码哈希存储、失败限速
- ✉️ **邮件密钥内置**：沿用原项目那把有效的 Pingram 密钥，开箱即用，一般无需改动
- 🔐 **凭证两种来源**：Access Key，或 **IAM 实例角色**（部署在 EC2 上时凭证完全不落盘）
- 🐧 **systemd 服务**：开机自启、崩溃自动重启、日志进 journald、沙箱加固
- 🎯 **监控项可编辑**：在界面上增删要盯的配额代码，改动后自动重置基线避免误报

## 系统要求

- Ubuntu 20.04 / 22.04 / 24.04 或 Debian 11+（其它 systemd 发行版应该也可以）
- Python 3.9+
- 能访问 AWS API 和邮件 API 的网络

## 安装

```bash
# 把整个目录传到服务器，例如 ~/ec2-quota-monitor-linux
cd ~/ec2-quota-monitor-linux
chmod +x install.sh uninstall.sh run.sh
sudo ./install.sh
```

安装脚本会创建系统用户 `ec2quota`、把代码装到 `/opt/ec2-quota-monitor`、
建好 venv、装上 systemd 服务并启动。重复执行即可升级（保留数据和配置）。

默认监听 `0.0.0.0:5000`（公网可访问），还需要放行端口：

```bash
sudo ufw allow 5000/tcp     # 以及 EC2 安全组的入站规则
```

浏览器打开 `http://<服务器IP>:5000`，**初始密码 `123`**。

## 登录与密码

- 单用户、只要密码，没有用户名。初始密码 `123`。
- 登录后界面上有「Web 访问密码」卡片，填当前密码 + 新密码（≥6 位，不能还是 `123`）即可修改。
  改完其它设备/浏览器上的登录状态会立即失效。
- 密码用 PBKDF2-SHA256 加盐哈希后存在 `config.json`，不存明文。
- 同一 IP 连续 5 次失败会锁定 5 分钟（可用 `EQM_LOGIN_*` 调整）。
- 登录状态默认保持 7 天（`EQM_SESSION_DAYS`）。
- **忘记密码**：清空 `/var/lib/ec2-quota-monitor/config.json` 里 `web.password_hash` 的值，
  重启服务即复位为 `123`：
  ```bash
  sudo systemctl stop ec2-quota-monitor
  sudo -u ec2quota python3 - <<'PY'
  import json, pathlib
  p = pathlib.Path("/var/lib/ec2-quota-monitor/config.json")
  c = json.loads(p.read_text("utf-8")); c["web"]["password_hash"] = ""
  p.write_text(json.dumps(c, indent=2, ensure_ascii=False), "utf-8")
  PY
  sudo systemctl start ec2-quota-monitor
  ```

> ⚠️ 明文 HTTP 下，登录密码和 AWS 凭证在链路上都是可见的。既然要公网访问，
> 强烈建议按 `deploy/nginx.conf.example` 加个域名 + certbot 上 HTTPS，
> 然后在 env 文件里打开 `EQM_COOKIE_SECURE=1` 和 `EQM_TRUST_PROXY=1`。
> 不想折腾 HTTPS 的话，把 `EQM_BIND` 改回 `127.0.0.1:5000`，用 SSH 端口转发访问：
> `ssh -L 5000:127.0.0.1:5000 <用户>@<服务器>`

### 不装服务，先跑起来看看

```bash
./run.sh              # gunicorn，127.0.0.1:5000
./run.sh --flask      # Flask 内置服务器，方便看报错
```

## 使用

1. **凭证来源**
   - *IAM 实例角色*（推荐，前提是这台机器就是 EC2）：给实例挂一个带 `deploy/iam-policy.json`
     里权限的角色，界面上选这一项即可，不用填任何密钥。
   - *Access Key*：填 Access Key / Secret Key。也可以写到
     `/etc/ec2-quota-monitor/ec2-quota-monitor.env` 里（`EQM_AWS_ACCESS_KEY_ID` /
     `EQM_AWS_SECRET_ACCESS_KEY`），这样凭证不会落到 `config.json`。
2. **区域 / 检查间隔** → 保存 → 点「测试 AWS」，会返回账号 ID 和权限检查结果。
3. **通知邮箱** → 保存 → 点「测试邮件」。
   邮件 API Key 已内置一把可用的（原项目那把），留空即不修改；
   要换成别的就在界面上填，或用 env 文件里的 `EQM_EMAIL_API_KEY` 覆盖（优先级最高）。
4. **启动监控**。首轮检查在后台执行，只建立基线、不发邮件；之后每轮和基线比对，
   有变化才发信。
5. 需要盯别的配额时，在「当前配额」下方输入配额代码添加（例如 `L-1216C47A`）。

默认监控这两项（和 Windows 版一致）：

| 配额代码 | 含义 |
|---|---|
| `L-1216C47A` | Running On-Demand Standard (A, C, D, H, I, M, R, T, Z) instances |
| `L-34B43A08` | All Standard (A, C, D, H, I, M, R, T, Z) Spot Instance Requests |

## 服务管理

```bash
systemctl status ec2-quota-monitor
systemctl restart ec2-quota-monitor
systemctl stop ec2-quota-monitor
journalctl -u ec2-quota-monitor -f        # 实时日志
journalctl -u ec2-quota-monitor --since today
```

## 目录结构

```
ec2-quota-monitor-linux/
├── app.py                  # Flask 应用工厂 + API 路由
├── wsgi.py                 # gunicorn 入口
├── gunicorn.conf.py        # gunicorn 配置（workers 必须为 1）
├── auth.py                 # 登录门禁、会话、失败限速
├── security.py             # 密码哈希（PBKDF2，纯标准库）
├── config.py               # 配置读写（原子写入 + 线程锁）
├── aws_service.py          # Service Quotas 查询
├── email_service.py        # Pingram 邮件发送（带重试）
├── scheduler.py            # APScheduler 定时检查 + 变化比对
├── requirements.txt
├── install.sh / uninstall.sh / run.sh
├── templates/
│   ├── index.html          # 主界面
│   └── login.html          # 登录页
└── deploy/
    ├── ec2-quota-monitor.service      # systemd unit 模板
    ├── ec2-quota-monitor.env.example  # 环境变量样例
    ├── nginx.conf.example             # 反向代理样例
    └── iam-policy.json                # 最小 IAM 权限
```

安装后的运行时路径：

| 路径 | 内容 |
|---|---|
| `/opt/ec2-quota-monitor` | 代码 + venv（root 所有，只读） |
| `/var/lib/ec2-quota-monitor` | `config.json`（0600）、`quotas_history.json` |
| `/etc/ec2-quota-monitor/ec2-quota-monitor.env` | 环境变量（0640 root:ec2quota） |

## API

除 `/healthz` 和 `/login` 外，所有接口都要求已登录（未登录时 API 返回 401 + `need_login`，
页面请求重定向到登录页）。

| 接口 | 方法 | 说明 |
|------|------|------|
| `/healthz` | GET | 健康探针（免登录） |
| `/login` | GET/POST | 登录页 / 提交密码 |
| `/logout` | GET/POST | 退出登录 |
| `/api/config/password` | POST | 修改登录密码（需当前密码） |
| `/api/config` | GET | 当前配置（不含密钥明文） |
| `/api/config/aws` | POST | 更新凭证来源 / 区域 / 间隔 |
| `/api/config/email` | POST | 更新通知邮箱、邮件 API Key |
| `/api/config/quotas` | POST | 更新监控配额列表（会重置基线） |
| `/api/test-aws` | POST | 测试 AWS 连接 |
| `/api/test-email` | POST | 发送测试邮件 |
| `/api/quotas` | GET | 缓存的配额；`?live=1` 实时查 AWS |
| `/api/quotas/available` | GET | 列出该区域全部 EC2 配额，`?q=` 过滤 |
| `/api/status` | GET | 监控状态（含下次执行时间） |
| `/api/events` | GET | 最近 30 条检查事件 |
| `/api/monitor/start` \| `/stop` \| `/check` | POST | 启动 / 停止 / 立即检查 |
| `/api/monitor/reset-baseline` | POST | 重置基线 |
| `/api/regions` | GET | 区域列表 |

## 安全说明

- **界面能读写 AWS 凭证**，公网暴露时登录密码就是唯一的门。第一件事就是把 `123` 改掉，
  并尽快套上 HTTPS。
- 会话 Cookie 为 HttpOnly + SameSite=Lax；HTTPS 环境下设 `EQM_COOKIE_SECURE=1` 追加 Secure 标记。
- 登录失败按 IP 限速（默认 5 次 / 5 分钟窗口 → 锁 5 分钟），日志里能看到失败来源 IP。
- `config.json` 权限 0600，属主 `ec2quota`；AWS Secret Key 和登录密码都不会回传给浏览器。
- systemd unit 做了沙箱限制：无 capability、`ProtectSystem=strict`，
  只有 `/var/lib/ec2-quota-monitor` 可写。
- IAM 只需要 `deploy/iam-policy.json` 里那几个只读权限，不要给管理员权限。

## 与 Windows 版的行为差异

移植时顺手修掉了几个会影响长期运行的问题：

| # | Windows 版的问题 | Linux 版做法 |
|---|---|---|
| 1 | `stop()` 调 `scheduler.shutdown()`，APScheduler 关掉就不能再 start，"停止→再启动"会抛异常 | 调度器常驻，只增删 job |
| 2 | 改了检查间隔不重新排程，必须重启进程 | 保存后立即 `reschedule_job` |
| 3 | 邮件发送失败仍然覆盖基线 → 那次配额变化永久丢失 | 失败保留旧基线，下一轮重试，连续 5 次才放弃 |
| 4 | `/api/config` 把 AWS Secret Key 明文回传给浏览器（`to_dict(safe=True)` 里 `safe` 没生效） | 只回传"是否已配置" |
| 5 | 邮件 API Key 只能改源码 | 仍内置同一把默认密钥（开箱可用），但可在界面上改或用 `EQM_EMAIL_API_KEY` 覆盖 |
| 6 | 监听 `0.0.0.0:5000`，Flask 开发服务器，**完全没有认证** | gunicorn + 强制登录（密码哈希、失败限速、会话 Cookie） |
| 7 | 「启动监控」的 HTTP 请求同步等完整一轮检查 + 发邮件 | 首轮检查交给调度线程，接口立即返回 |
| 8 | 配额写文件非原子，进程被 kill 可能留下半个 JSON | 临时文件 + `os.replace` |
| 9 | 进程重启后监控状态丢失，需要手工点「启动监控」 | 状态持久化，服务重启自动恢复 |
| 10 | `_get_quota_usage()` 是死代码且有 bug（两次写同一个 key、配额代码是编造的） | 删除；使用量统一显示为 N/A |

另外新增：登录保护（初始密码 123，界面内可改）、IAM 角色支持、监控配额在线编辑、
事件时间线、`/healthz`、区域列表补全。

## 常见问题

**Q: 服务起不来？**
```bash
journalctl -u ec2-quota-monitor -n 50 --no-pager
```
多半是依赖没装好（重跑 `sudo ./install.sh`）或端口被占（`ss -lntp | grep 5000`）。

**Q: 浏览器打不开 `http://<IP>:5000`？**
依次确认：服务在跑（`systemctl status`）、端口在听（`ss -lntp | grep 5000`）、
`EQM_BIND` 不是 `127.0.0.1`、系统防火墙放行（`sudo ufw allow 5000/tcp`）、
云厂商安全组入站规则放行。

**Q: 登录提示"尝试次数过多"？**
同一 IP 失败 5 次会锁 5 分钟，等一会儿即可；也可以 `systemctl restart ec2-quota-monitor`
清掉计数（限速表在内存里）。

**Q: 测试 AWS 报权限不足？**
IAM 用户/角色需要 `servicequotas:GetServiceQuota` 和 `servicequotas:ListServiceQuotas`，
见 `deploy/iam-policy.json`。

**Q: 选了 IAM 角色但连不上？**
确认这台机器是 EC2 且已附加角色：`curl -s http://169.254.169.254/latest/meta-data/iam/info`
（IMDSv2 需要先取 token）。非 EC2 环境可以改用 `~/.aws/credentials`，同样走这个选项。

**Q: 邮件收不到？**
先点「测试邮件」看返回。API Key 无效会返回 4xx（不重试并直接报错）；
5xx / 网络错误会自动重试 3 次。

**Q: 为什么 gunicorn 只能 1 个 worker？**
每个 worker 进程都会跑一份 APScheduler，多 worker 会重复检查、重复发邮件。
Web 请求很轻，靠 `EQM_THREADS`（默认 4 线程）足够。

**Q: 怎么从 Windows 版迁移历史记录？**
把旧的 `data/quotas_history.json` 复制到 `/var/lib/ec2-quota-monitor/` 即可
（`chown ec2quota:ec2quota`）。`config.json` 不建议直接搬，凭证请在界面重填一次。

## 许可证

MIT License
