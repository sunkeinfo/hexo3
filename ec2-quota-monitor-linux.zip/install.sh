#!/usr/bin/env bash
#
# EC2 Quota Monitor - Ubuntu/Debian 安装脚本
#
#   sudo ./install.sh
#
# 会做这些事（幂等，可重复执行以升级）：
#   1. 创建系统用户 ec2quota（无登录 shell）
#   2. 把代码装到 /opt/ec2-quota-monitor，建 venv 并安装依赖
#   3. 数据目录 /var/lib/ec2-quota-monitor（0700，归 ec2quota）
#   4. 环境变量文件 /etc/ec2-quota-monitor/ec2-quota-monitor.env（0640）
#   5. 安装并启动 systemd 服务 ec2-quota-monitor
#
set -euo pipefail

APP_NAME="ec2-quota-monitor"
APP_DIR="${APP_DIR:-/opt/${APP_NAME}}"
DATA_DIR="${DATA_DIR:-/var/lib/${APP_NAME}}"
ETC_DIR="${ETC_DIR:-/etc/${APP_NAME}}"
SERVICE_USER="${SERVICE_USER:-ec2quota}"
UNIT_FILE="/etc/systemd/system/${APP_NAME}.service"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

info()  { printf '\033[1;34m[信息]\033[0m %s\n' "$*"; }
ok()    { printf '\033[1;32m[成功]\033[0m %s\n' "$*"; }
warn()  { printf '\033[1;33m[警告]\033[0m %s\n' "$*"; }
die()   { printf '\033[1;31m[错误]\033[0m %s\n' "$*" >&2; exit 1; }

# ---------- 前置检查 ----------

[[ $EUID -eq 0 ]] || die "请用 root 运行: sudo $0"

command -v systemctl >/dev/null 2>&1 || die "未检测到 systemd，本脚本只支持 systemd 系统"
command -v python3 >/dev/null 2>&1 || die "未安装 python3，请先执行: apt-get install -y python3"

PY_VERSION="$(python3 -c 'import sys; print("%d.%d" % sys.version_info[:2])')"
info "Python 版本: ${PY_VERSION}"
python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' \
  || die "需要 Python 3.9 及以上"

# Ubuntu 上 venv 需要单独的包
if ! python3 -c 'import venv, ensurepip' >/dev/null 2>&1; then
  info "缺少 python3-venv，正在安装..."
  apt-get update -qq
  DEBIAN_FRONTEND=noninteractive apt-get install -y -qq "python3-venv" \
    || die "安装 python3-venv 失败，请手动执行: apt-get install -y python3-venv python3-pip"
fi

# ---------- 用户与目录 ----------

if id "${SERVICE_USER}" >/dev/null 2>&1; then
  info "系统用户 ${SERVICE_USER} 已存在"
else
  info "创建系统用户 ${SERVICE_USER}"
  useradd --system --no-create-home --home-dir "${DATA_DIR}" --shell /usr/sbin/nologin "${SERVICE_USER}"
fi

install -d -m 0755 -o root -g root "${APP_DIR}"
install -d -m 0700 -o "${SERVICE_USER}" -g "${SERVICE_USER}" "${DATA_DIR}"
install -d -m 0750 -o root -g "${SERVICE_USER}" "${ETC_DIR}"

# ---------- 拷贝代码 ----------

if [[ "${SRC_DIR}" == "${APP_DIR}" ]]; then
  info "已在 ${APP_DIR} 中运行，跳过拷贝"
else
  info "拷贝代码到 ${APP_DIR}"
  for item in app.py auth.py aws_service.py config.py email_service.py scheduler.py security.py \
              wsgi.py gunicorn.conf.py requirements.txt templates deploy README.md; do
    [[ -e "${SRC_DIR}/${item}" ]] || { warn "缺少 ${item}，跳过"; continue; }
    cp -a "${SRC_DIR}/${item}" "${APP_DIR}/"
  done
  # 注意：不拷贝 data/（可能含凭证），配置请通过 Web 界面或环境变量提供
fi
chown -R root:root "${APP_DIR}"
chmod -R go-w "${APP_DIR}"

# ---------- Python 虚拟环境 ----------

if [[ -x "${APP_DIR}/.venv/bin/python" ]]; then
  info "复用已有虚拟环境"
else
  info "创建虚拟环境 ${APP_DIR}/.venv"
  python3 -m venv "${APP_DIR}/.venv"
fi

info "安装/升级 Python 依赖（可能需要一两分钟）"
"${APP_DIR}/.venv/bin/pip" install --quiet --upgrade pip
"${APP_DIR}/.venv/bin/pip" install --quiet --upgrade -r "${APP_DIR}/requirements.txt"
ok "依赖安装完成"

# ---------- 环境变量文件 ----------

ENV_FILE="${ETC_DIR}/${APP_NAME}.env"
if [[ -f "${ENV_FILE}" ]]; then
  info "保留已有配置 ${ENV_FILE}"
else
  info "生成 ${ENV_FILE}"
  cp "${APP_DIR}/deploy/${APP_NAME}.env.example" "${ENV_FILE}"
fi
chown root:"${SERVICE_USER}" "${ENV_FILE}"
chmod 0640 "${ENV_FILE}"

# ---------- systemd ----------

info "安装 systemd 服务"
sed -e "s|__APP_DIR__|${APP_DIR}|g" \
    -e "s|__DATA_DIR__|${DATA_DIR}|g" \
    -e "s|__ETC_DIR__|${ETC_DIR}|g" \
    -e "s|__SERVICE_USER__|${SERVICE_USER}|g" \
    "${APP_DIR}/deploy/${APP_NAME}.service" > "${UNIT_FILE}"
chmod 0644 "${UNIT_FILE}"

systemctl daemon-reload
systemctl enable "${APP_NAME}" >/dev/null
systemctl restart "${APP_NAME}"

sleep 2
if systemctl is-active --quiet "${APP_NAME}"; then
  ok "服务已启动"
else
  warn "服务未能启动，最近日志："
  journalctl -u "${APP_NAME}" -n 30 --no-pager || true
  exit 1
fi

BIND_ADDR="$(grep -E '^\s*EQM_BIND=' "${ENV_FILE}" | tail -n1 | cut -d= -f2- | tr -d '"' || true)"
BIND_ADDR="${BIND_ADDR:-0.0.0.0:5000}"
PORT="${BIND_ADDR##*:}"
PUBLIC_IP="$(curl -s --max-time 3 http://checkip.amazonaws.com 2>/dev/null | tr -d '[:space:]' || true)"
PUBLIC_IP="${PUBLIC_IP:-<服务器IP>}"

cat <<EOF

============================================
  安装完成
============================================

Web 界面 : http://${PUBLIC_IP}:${PORT}
初始密码 : 123        <-- 登录后请立刻在「Web 访问密码」里改掉

代码目录 : ${APP_DIR}
数据目录 : ${DATA_DIR}   (config.json / quotas_history.json)
配置文件 : ${ENV_FILE}

常用命令:
  systemctl status ${APP_NAME}
  systemctl restart ${APP_NAME}
  journalctl -u ${APP_NAME} -f

监听地址 ${BIND_ADDR}（改 ${ENV_FILE} 里的 EQM_BIND 可调整）。
公网访问还需要放行端口:
  sudo ufw allow ${PORT}/tcp        # 以及 EC2 安全组的入站规则

⚠ 目前是明文 HTTP：登录密码和 AWS 凭证在链路上可被截获。
  建议按 ${APP_DIR}/deploy/nginx.conf.example 套上 HTTPS，
  再在 ${ENV_FILE} 里打开 EQM_COOKIE_SECURE=1 与 EQM_TRUST_PROXY=1。

下一步：用初始密码 123 登录 -> 立刻改密码 -> 填 AWS 凭证（或选 IAM 实例角色）
和通知邮箱 -> 点"测试 AWS"、"测试邮件"确认无误 -> 启动监控。
邮件密钥已内置，一般不用改。
EOF
