"""
邮件发送模块 - 通过 Pingram API 发送通知

与 Windows 版的差异：
- 复用一个 httpx.Client（长驻进程里每次新建连接池是浪费）
- 5xx / 网络错误时做有限次重试
- API Key 缺失时给出明确报错，而不是发出去被 401
"""
import logging
import time
from datetime import datetime
from typing import List, Optional

import httpx

logger = logging.getLogger(__name__)

_MAX_ATTEMPTS = 3
_RETRY_BACKOFF_SECONDS = 2


class EmailService:
    def __init__(self):
        self._client: Optional[httpx.Client] = None

    def _get_client(self) -> httpx.Client:
        if self._client is None or self._client.is_closed:
            self._client = httpx.Client(timeout=30.0)
        return self._client

    def close(self):
        if self._client is not None and not self._client.is_closed:
            self._client.close()

    def send_email(self, to_email: str, subject: str, content: str) -> dict:
        from config import config

        if not config.email_api_key:
            return {"success": False, "error": "邮件 API Key 未配置（EQM_EMAIL_API_KEY 或 config.json）"}
        if not to_email:
            return {"success": False, "error": "收件邮箱为空"}

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {config.email_api_key}",
        }
        payload = {
            "type": config.email_notification_type,
            "to": {"email": to_email},
            "parameters": {"subject": subject, "comment": content},
            "templateId": config.email_template_id,
        }

        last_error = "未知错误"
        for attempt in range(1, _MAX_ATTEMPTS + 1):
            try:
                response = self._get_client().post(config.email_api_url, headers=headers, json=payload)
            except httpx.HTTPError as e:
                last_error = f"网络错误: {e}"
                logger.warning("邮件发送失败（第 %d/%d 次）: %s", attempt, _MAX_ATTEMPTS, last_error)
            else:
                if response.status_code in (200, 201, 202):
                    logger.info("邮件发送成功: %s", to_email)
                    return {"success": True, "response": response.text}

                last_error = f"HTTP {response.status_code}: {response.text[:500]}"
                # 4xx 是请求本身的问题，重试没意义
                if 400 <= response.status_code < 500:
                    logger.error("邮件发送失败（不重试）: %s", last_error)
                    return {"success": False, "error": last_error}
                logger.warning("邮件发送失败（第 %d/%d 次）: %s", attempt, _MAX_ATTEMPTS, last_error)

            if attempt < _MAX_ATTEMPTS:
                time.sleep(_RETRY_BACKOFF_SECONDS * attempt)

        logger.error("邮件发送最终失败: %s", last_error)
        return {"success": False, "error": last_error}

    def send_quota_change_notification(
        self,
        to_email: str,
        changes: List[dict],
        region: str,
        old_quotas: Optional[dict] = None,
        new_quotas: Optional[dict] = None,
    ) -> dict:
        if not changes:
            logger.info("没有变化，跳过发送通知")
            return {"success": True, "message": "No changes to report"}

        subject = f"AWS EC2 Quota 变化通知 - {region}"

        lines = [
            "AWS EC2 配额检测到变化",
            f"区域: {region}",
            f"时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S %Z').strip()}",
            "",
            "=" * 50,
            "变化详情:",
            "=" * 50,
            "",
        ]

        for change in changes:
            change_type = change.get("type", "unknown")
            name = change.get("name", "Unknown")
            code = change.get("code", "Unknown")

            if change_type == "added":
                lines += [
                    f"✅ 新增配额: {name}",
                    f"   代码: {code}",
                    "   上次检查: 无记录",
                    f"   本次检查: {change.get('new_value', 'N/A')}",
                ]
            elif change_type == "removed":
                lines += [
                    f"❌ 删除配额: {name}",
                    f"   代码: {code}",
                    f"   上次检查: {change.get('old_value', 'N/A')}",
                    "   本次检查: 已删除",
                ]
            elif change_type == "changed":
                lines += [
                    f"🔄 配额变化: {name}",
                    f"   代码: {code}",
                    f"   上次检查: {change.get('old_value', 'N/A')}",
                    f"   本次检查: {change.get('new_value', 'N/A')}",
                ]
            elif change_type == "usage_changed":
                lines += [
                    f"📊 使用量变化: {name}",
                    f"   代码: {code}",
                    f"   上次检查: {change.get('old_usage', 'N/A')}",
                    f"   本次检查: {change.get('new_usage', 'N/A')}",
                    f"   配额上限: {change.get('limit', 'N/A')}",
                ]
            lines.append("")

        if old_quotas is not None and new_quotas is not None:
            lines += ["=" * 50, "所有监控配额对比:", "=" * 50, ""]
            for code in sorted(set(old_quotas) | set(new_quotas)):
                old_info = old_quotas.get(code)
                new_info = new_quotas.get(code)
                quota_name = (new_info or old_info or {}).get("name", code)
                lines += [
                    f"配额: {quota_name}",
                    f"   代码: {code}",
                    f"   上次检查: {old_info['value'] if old_info else '无记录'}",
                    f"   本次检查: {new_info['value'] if new_info else '已删除'}",
                    "",
                ]

        lines += ["=" * 50, "此邮件由 EC2 Quota Monitor 自动发送"]

        return self.send_email(to_email, subject, "\n".join(lines))

    def send_test_email(self, to_email: str) -> dict:
        subject = "EC2 Quota Monitor - 测试邮件"
        content = (
            "这是一封测试邮件。\n\n"
            "EC2 Quota Monitor 服务（Linux 版）已成功启动。\n\n"
            f"时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
            "如果您收到此邮件，说明邮件通知功能正常工作。\n"
        )
        return self.send_email(to_email, subject, content)


email_service = EmailService()
