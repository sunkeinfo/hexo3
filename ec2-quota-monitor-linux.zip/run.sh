#!/usr/bin/env bash
#
# 本地/前台运行（开发调试用，不装 systemd 服务）
#
#   ./run.sh              # gunicorn，监听 127.0.0.1:5000
#   EQM_BIND=0.0.0.0:5000 ./run.sh
#   ./run.sh --flask      # 用 Flask 内置服务器（便于看 traceback）
#
set -euo pipefail

cd "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

VENV=".venv"
if [[ ! -x "${VENV}/bin/python" ]]; then
  echo "[信息] 创建虚拟环境 ${VENV}"
  python3 -m venv "${VENV}"
  "${VENV}/bin/pip" install --quiet --upgrade pip
  "${VENV}/bin/pip" install --quiet -r requirements.txt
fi

export EQM_DATA_DIR="${EQM_DATA_DIR:-$(pwd)/data}"
mkdir -p "${EQM_DATA_DIR}"

if [[ "${1:-}" == "--flask" ]]; then
  export EQM_HOST="${EQM_HOST:-127.0.0.1}"
  export EQM_PORT="${EQM_PORT:-5000}"
  echo "[信息] Flask 调试服务器 http://${EQM_HOST}:${EQM_PORT}"
  exec "${VENV}/bin/python" app.py
fi

export EQM_BIND="${EQM_BIND:-127.0.0.1:5000}"
echo "[信息] gunicorn http://${EQM_BIND}"
exec "${VENV}/bin/gunicorn" -c gunicorn.conf.py wsgi:app
