"""
配置管理模块（Linux 版）

与 Windows 版的差异：
- 数据目录可通过 EQM_DATA_DIR 指定（systemd 部署时指向 /var/lib/ec2-quota-monitor）
- 配置写入是原子的（临时文件 + os.replace），并加线程锁，
  避免 Web 线程与调度线程同时写入导致 config.json 被截断
- config.json 权限固定为 0600（内含 AWS 凭证）
- 敏感项（AWS Secret Key、邮件 API Key）支持用环境变量覆盖，
  以便凭证不落盘（见 deploy/ec2-quota-monitor.env.example）
"""
import json
import os
import secrets
import tempfile
import threading
from pathlib import Path

from security import DEFAULT_PASSWORD, hash_password, verify_password

BASE_DIR = Path(__file__).resolve().parent


def _resolve_data_dir() -> Path:
    env = os.environ.get("EQM_DATA_DIR", "").strip()
    return Path(env) if env else BASE_DIR / "data"


DATA_DIR = _resolve_data_dir()
DATA_DIR.mkdir(parents=True, exist_ok=True)

CONFIG_FILE = DATA_DIR / "config.json"
QUOTAS_HISTORY_FILE = DATA_DIR / "quotas_history.json"

DEFAULT_CONFIG = {
    # "keys" = 使用下面的 Access Key / Secret Key
    # "iam_role" = 使用默认凭证链（EC2 实例角色 / 环境变量 / ~/.aws/credentials）
    "credentials_source": "keys",
    "aws_access_key": "",
    "aws_secret_key": "",
    "aws_region": "us-east-1",
    "check_interval": 10,
    "monitored_quotas": {
        "L-34B43A08": "All Standard (A, C, D, H, I, M, R, T, Z) Spot Instance Requests",
        "L-1216C47A": "Running On-Demand Standard (A, C, D, H, I, M, R, T, Z) instances",
    },
    "email": {
        "api_url": "https://api.pingram.io/send",
        # 沿用原项目里那把有效的 Pingram 密钥，开箱即用、一般无需改动。
        # 需要更换时：界面上填新的，或用 EQM_EMAIL_API_KEY 环境变量覆盖（优先级最高）。
        "api_key": (
            "pingram_sk_eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9."
            "eyJqdGkiOiJrZXlfOTRjZDJlOGFkOTYwMzU1OTJlOTAzZWI5NmU5ZDg5M2IiLCJ2ZXJzaW9uIjoxLCJhY2NvdW50SWQiOiIwOTdi"
            "dWx1bGJkamZtOTY5eHJtcmlqaXo0MyIsImtleVR5cGUiOiJzZWNyZXQiLCJlbnZpcm9ubWVudElkIjoiMDk3YnVsdWxiZGpmbTk2"
            "OXhybXJpaml6NDMifQ.iNezQ3sgydRwDtWBQsYTITkfM9nEPeV5eS8VXBYYmDg"
        ),
        "template_id": "awsdo_com",
        "notification_type": "awsdo_com_notification",
        "to_address": "",
    },
    # Web 登录：初始密码见 security.DEFAULT_PASSWORD（"123"），登录后在界面上修改。
    # password_hash 为空表示"仍是初始密码"，忘记密码时把这一项清空并重启即可复位。
    "web": {
        "password_hash": "",
        "session_secret": "",
    },
    # 监控开关持久化：systemd 重启 / 服务器重启后自动恢复监控
    "monitor_enabled": False,
    "is_configured": False,
}


def _atomic_write_json(path: Path, data: dict, mode: int = 0o600):
    """原子写入 JSON，避免进程被 kill 时留下半个文件"""
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(dir=str(path.parent), prefix=f".{path.name}.", suffix=".tmp")
    tmp = Path(tmp_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
            f.flush()
            os.fsync(f.fileno())
        os.chmod(tmp, mode)
        os.replace(tmp, path)
    except BaseException:
        tmp.unlink(missing_ok=True)
        raise


def _merge_defaults(data: dict) -> dict:
    """补全缺失字段，保证旧配置文件升级后可用"""
    for key, val in DEFAULT_CONFIG.items():
        if key not in data:
            data[key] = json.loads(json.dumps(val))  # 深拷贝
    for section in ("email", "web"):
        if not isinstance(data.get(section), dict):
            data[section] = dict(DEFAULT_CONFIG[section])
        else:
            for k, v in DEFAULT_CONFIG[section].items():
                data[section].setdefault(k, v)
    if not isinstance(data.get("monitored_quotas"), dict) or not data["monitored_quotas"]:
        data["monitored_quotas"] = dict(DEFAULT_CONFIG["monitored_quotas"])
    return data


class Config:
    def __init__(self):
        self._lock = threading.RLock()
        self._config = self._load()

    # ---------- 读写底座 ----------

    def _load(self) -> dict:
        if CONFIG_FILE.exists():
            try:
                with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                    return _merge_defaults(json.load(f))
            except (json.JSONDecodeError, OSError):
                # 配置损坏时不要让服务起不来，改名备份后用默认值
                try:
                    CONFIG_FILE.rename(CONFIG_FILE.with_suffix(".json.broken"))
                except OSError:
                    pass
        return _merge_defaults({})

    def save(self):
        with self._lock:
            _atomic_write_json(CONFIG_FILE, self._config)

    def reload(self):
        """手动编辑过 config.json 之后可以调用它重新载入"""
        with self._lock:
            self._config = self._load()

    def _set(self, key: str, value):
        with self._lock:
            self._config[key] = value
            self.save()

    def _set_email(self, key: str, value):
        with self._lock:
            self._config["email"][key] = value
            self.save()

    # ---------- AWS ----------

    @property
    def credentials_source(self) -> str:
        return self._config.get("credentials_source", "keys")

    @credentials_source.setter
    def credentials_source(self, value: str):
        self._set("credentials_source", "iam_role" if value == "iam_role" else "keys")

    @property
    def use_iam_role(self) -> bool:
        return self.credentials_source == "iam_role"

    @property
    def aws_access_key(self) -> str:
        return os.environ.get("EQM_AWS_ACCESS_KEY_ID") or self._config.get("aws_access_key", "")

    @aws_access_key.setter
    def aws_access_key(self, value: str):
        self._set("aws_access_key", value)

    @property
    def aws_secret_key(self) -> str:
        return os.environ.get("EQM_AWS_SECRET_ACCESS_KEY") or self._config.get("aws_secret_key", "")

    @aws_secret_key.setter
    def aws_secret_key(self, value: str):
        self._set("aws_secret_key", value)

    @property
    def aws_region(self) -> str:
        return self._config.get("aws_region", "us-east-1")

    @aws_region.setter
    def aws_region(self, value: str):
        self._set("aws_region", value or "us-east-1")

    @property
    def check_interval(self) -> int:
        try:
            value = int(self._config.get("check_interval", 10))
        except (TypeError, ValueError):
            return 10
        return min(max(value, 1), 1440)

    @check_interval.setter
    def check_interval(self, value: int):
        self._set("check_interval", min(max(int(value), 1), 1440))

    @property
    def monitored_quotas(self) -> dict:
        return dict(self._config.get("monitored_quotas") or DEFAULT_CONFIG["monitored_quotas"])

    @monitored_quotas.setter
    def monitored_quotas(self, value: dict):
        cleaned = {
            str(k).strip(): str(v).strip()
            for k, v in (value or {}).items()
            if str(k).strip()
        }
        if not cleaned:
            raise ValueError("监控配额列表不能为空")
        self._set("monitored_quotas", cleaned)

    # ---------- 邮件 ----------

    @property
    def email_api_url(self) -> str:
        return self._config["email"].get("api_url") or DEFAULT_CONFIG["email"]["api_url"]

    @property
    def email_api_key(self) -> str:
        return os.environ.get("EQM_EMAIL_API_KEY") or self._config["email"].get("api_key", "")

    @email_api_key.setter
    def email_api_key(self, value: str):
        self._set_email("api_key", value)

    @property
    def email_template_id(self) -> str:
        return self._config["email"].get("template_id") or DEFAULT_CONFIG["email"]["template_id"]

    @property
    def email_notification_type(self) -> str:
        return self._config["email"].get("notification_type") or DEFAULT_CONFIG["email"]["notification_type"]

    @property
    def notification_email(self) -> str:
        return self._config["email"].get("to_address", "")

    @notification_email.setter
    def notification_email(self, value: str):
        self._set_email("to_address", value)

    # ---------- Web 登录 ----------

    def _set_web(self, key: str, value):
        with self._lock:
            self._config["web"][key] = value
            self.save()

    @property
    def session_secret(self) -> str:
        """会话签名密钥：持久化，这样服务重启不会把所有人踢下线"""
        env = os.environ.get("EQM_SECRET_KEY", "").strip()
        if env:
            return env
        with self._lock:
            secret = self._config["web"].get("session_secret") or ""
            if not secret:
                secret = secrets.token_hex(32)
                self._config["web"]["session_secret"] = secret
                self.save()
            return secret

    def rotate_session_secret(self) -> str:
        """换掉会话密钥 —— 改密码时调用，让其它设备上的登录状态立即失效"""
        secret = secrets.token_hex(32)
        self._set_web("session_secret", secret)
        return secret

    @property
    def is_default_password(self) -> bool:
        """是否仍在用初始密码 —— 界面上要一直提醒到改掉为止"""
        stored = self._config["web"].get("password_hash") or ""
        return True if not stored else verify_password(DEFAULT_PASSWORD, stored)

    def verify_web_password(self, password: str) -> bool:
        stored = self._config["web"].get("password_hash") or ""
        if not stored:
            # 首次登录：接受初始密码，并顺手把它哈希存下来
            if password == DEFAULT_PASSWORD:
                self.set_web_password(DEFAULT_PASSWORD)
                return True
            return False
        return verify_password(password, stored)

    def set_web_password(self, password: str):
        self._set_web("password_hash", hash_password(password))

    # ---------- 状态 ----------

    @property
    def monitor_enabled(self) -> bool:
        return bool(self._config.get("monitor_enabled", False))

    @monitor_enabled.setter
    def monitor_enabled(self, value: bool):
        self._set("monitor_enabled", bool(value))

    @property
    def is_configured(self) -> bool:
        return bool(self._config.get("is_configured", False))

    def set_configured(self, value: bool):
        self._set("is_configured", bool(value))

    def has_credentials(self) -> bool:
        """判断凭证是否齐备（IAM 角色模式下由 boto3 凭证链负责）"""
        if self.use_iam_role:
            return True
        return bool(self.aws_access_key and self.aws_secret_key)

    # ---------- 导出 ----------

    def to_dict(self, safe: bool = True) -> dict:
        """
        safe=True 时不返回明文密钥，只告知"已配置"。
        Windows 版会把 Secret Key 原样回填到网页表单里，这里改掉了。
        """
        data = {
            "credentials_source": self.credentials_source,
            "aws_access_key": self.aws_access_key,
            "aws_region": self.aws_region,
            "check_interval": self.check_interval,
            "monitored_quotas": self.monitored_quotas,
            "notification_email": self.notification_email,
            "monitor_enabled": self.monitor_enabled,
            "is_configured": self.is_configured,
            "has_secret_key": bool(self.aws_secret_key),
            "has_email_api_key": bool(self.email_api_key),
            "email_api_key_from_env": bool(os.environ.get("EQM_EMAIL_API_KEY")),
            "is_default_password": self.is_default_password,
            "data_dir": str(DATA_DIR),
        }
        if not safe:
            data["aws_secret_key"] = self.aws_secret_key
        return data


config = Config()
