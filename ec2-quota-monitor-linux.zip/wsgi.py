"""
gunicorn 入口：gunicorn -c gunicorn.conf.py wsgi:app

注意：必须只跑 1 个 worker。每个 worker 进程都会启动自己的 APScheduler，
多 worker 会导致同一次配额变化被重复检查并重复发邮件。
并发靠线程（gunicorn.conf.py 里的 threads）解决，Web 请求本身很轻。
"""
from app import create_app

app = create_app()
