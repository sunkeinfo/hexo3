"""
AWS EC2 Quota 查询模块

与 Windows 版的差异：
- 支持 IAM 实例角色 / 默认凭证链（部署在 EC2 上时无需把 Access Key 写到磁盘）
- 给 botocore 配置了超时和重试，避免网络抖动时调度线程被长时间挂住
- 删掉了 Windows 版里的死代码（_get_quota_usage 里两次写同一个 key，
  且 quota code 是编造的；MONITORED_QUOTAS = property(...) 在模块级也没有意义）
"""
import logging
from typing import Dict, List, Optional, Tuple

import boto3
from botocore.config import Config as BotoConfig
from botocore.exceptions import BotoCoreError, ClientError, NoCredentialsError

from config import config as _config

logger = logging.getLogger(__name__)

# Service Quotas 与 STS 调用的公共客户端参数
_BOTO_CONFIG = BotoConfig(
    connect_timeout=10,
    read_timeout=20,
    retries={"max_attempts": 3, "mode": "standard"},
    user_agent_extra="ec2-quota-monitor/linux",
)


def get_monitored_quotas_map() -> dict:
    """从配置文件读取需要监控的配额列表"""
    return _config.monitored_quotas


class EC2QuotaService:
    """EC2 配额查询服务"""

    def __init__(
        self,
        access_key: Optional[str] = None,
        secret_key: Optional[str] = None,
        region: str = "us-east-1",
        use_iam_role: bool = False,
    ):
        self.access_key = access_key or ""
        self.secret_key = secret_key or ""
        self.region = region or "us-east-1"
        self.use_iam_role = use_iam_role or not (self.access_key and self.secret_key)
        self._session = None
        self._client = None

    @classmethod
    def from_config(cls) -> "EC2QuotaService":
        """按当前配置构造实例"""
        return cls(
            access_key=_config.aws_access_key,
            secret_key=_config.aws_secret_key,
            region=_config.aws_region,
            use_iam_role=_config.use_iam_role,
        )

    def _get_session(self):
        if self._session is None:
            if self.use_iam_role:
                # 默认凭证链：环境变量 -> ~/.aws -> EC2 实例元数据(IMDSv2)
                self._session = boto3.Session(region_name=self.region)
            else:
                self._session = boto3.Session(
                    aws_access_key_id=self.access_key,
                    aws_secret_access_key=self.secret_key,
                    region_name=self.region,
                )
        return self._session

    def _get_client(self):
        """Service Quotas 客户端"""
        if self._client is None:
            self._client = self._get_session().client("service-quotas", config=_BOTO_CONFIG)
        return self._client

    def get_monitored_quotas(self) -> Dict[str, dict]:
        """
        获取需要监控的配额

        Returns:
            Dict[str, dict]: 配额代码 -> 配额信息
        """
        quotas: Dict[str, dict] = {}
        client = self._get_client()

        for quota_code, fallback_name in get_monitored_quotas_map().items():
            try:
                response = client.get_service_quota(ServiceCode="ec2", QuotaCode=quota_code)
            except ClientError as e:
                # 单个配额取不到不应该让整轮检查失败
                logger.warning("无法获取配额 %s: %s", quota_code, e)
                continue
            except (BotoCoreError, NoCredentialsError) as e:
                # 凭证 / 网络问题是全局性的，直接抛给调用方
                logger.error("查询配额 %s 时出错: %s", quota_code, e)
                raise

            quota = response["Quota"]
            quotas[quota_code] = {
                "code": quota_code,
                "name": quota.get("QuotaName") or fallback_name,
                "value": quota["Value"],
                "unit": quota.get("Unit", "None"),
                "adjustable": quota.get("Adjustable", False),
                "global_quota": quota.get("GlobalQuota", False),
                "usage": None,
            }

        if not quotas:
            raise RuntimeError("没有获取到任何配额，请检查配额代码、区域和 IAM 权限")

        return quotas

    def get_all_ec2_quotas(self) -> Dict[str, dict]:
        """兼容旧接口名，返回监控中的配额"""
        return self.get_monitored_quotas()

    def get_quota_by_code(self, quota_code: str) -> Optional[dict]:
        """按配额代码查询单个配额，不存在时返回 None"""
        try:
            response = self._get_client().get_service_quota(ServiceCode="ec2", QuotaCode=quota_code)
        except ClientError as e:
            if e.response["Error"]["Code"] in ("NoSuchResourceException", "ResourceNotFoundException"):
                return None
            raise

        quota = response["Quota"]
        return {
            "code": quota["QuotaCode"],
            "name": quota["QuotaName"],
            "value": quota["Value"],
            "unit": quota.get("Unit", "None"),
            "adjustable": quota.get("Adjustable", False),
            "global_quota": quota.get("GlobalQuota", False),
        }

    def list_ec2_quotas(self, keyword: str = "") -> List[dict]:
        """
        列出该区域所有 EC2 配额，供在网页上挑选要监控的项。
        keyword 非空时按名称/代码过滤（不区分大小写）。
        """
        client = self._get_client()
        keyword = (keyword or "").strip().lower()
        result: List[dict] = []

        paginator = client.get_paginator("list_service_quotas")
        for page in paginator.paginate(ServiceCode="ec2"):
            for quota in page.get("Quotas", []):
                name = quota.get("QuotaName", "")
                code = quota.get("QuotaCode", "")
                if keyword and keyword not in name.lower() and keyword not in code.lower():
                    continue
                result.append(
                    {
                        "code": code,
                        "name": name,
                        "value": quota.get("Value"),
                        "adjustable": quota.get("Adjustable", False),
                    }
                )

        result.sort(key=lambda q: q["name"])
        return result

    def test_connection(self) -> Tuple[bool, str]:
        """测试 AWS 连接，返回 (是否成功, 消息)"""
        try:
            session = self._get_session()
            source = "IAM 角色/默认凭证链" if self.use_iam_role else "Access Key"

            # 先确认凭证本身可用，顺带拿到账号信息
            identity = session.client("sts", config=_BOTO_CONFIG).get_caller_identity()
            # 再确认有 service-quotas 权限
            self._get_client().list_service_quotas(ServiceCode="ec2", MaxResults=1)

            return True, (
                f"连接成功（{source}）｜区域: {self.region}｜账号: {identity.get('Account', '未知')}"
            )
        except NoCredentialsError:
            return False, "找不到 AWS 凭证（IAM 角色模式下请确认实例已附加角色）"
        except ClientError as e:
            error = e.response.get("Error", {})
            code = error.get("Code", "")
            mapping = {
                "InvalidClientTokenId": "AWS Access Key 无效",
                "SignatureDoesNotMatch": "AWS Secret Key 无效",
                "UnauthorizedOperation": "没有权限访问 Service Quotas",
                "AccessDenied": "权限不足，请确认 IAM 策略包含 service-quotas:ListServiceQuotas",
                "AccessDeniedException": "权限不足，请确认 IAM 策略包含 service-quotas:ListServiceQuotas",
                "ExpiredToken": "凭证已过期",
            }
            return False, mapping.get(code, f"连接失败: {error.get('Message', code or str(e))}")
        except BotoCoreError as e:
            return False, f"连接失败（网络或配置问题）: {e}"
        except Exception as e:  # noqa: BLE001 - 兜底，保证 API 返回可读错误
            return False, f"连接失败: {e}"


def format_quotas_for_display(quotas: Dict[str, dict]) -> List[dict]:
    """格式化配额信息用于网页显示"""
    result = [
        {
            "code": code,
            "name": info.get("name", code),
            "limit": info.get("value"),
            "usage": info.get("usage"),
            "unit": info.get("unit", ""),
            "adjustable": info.get("adjustable", False),
        }
        for code, info in quotas.items()
    ]
    result.sort(key=lambda x: x["name"])
    return result


def compare_quotas(old_quotas: Dict[str, dict], new_quotas: Dict[str, dict]) -> List[dict]:
    """比较两次配额，返回变化列表"""
    changes: List[dict] = []

    for code, new_info in new_quotas.items():
        if code not in old_quotas:
            changes.append(
                {
                    "type": "added",
                    "code": code,
                    "name": new_info.get("name", code),
                    "old_value": None,
                    "new_value": new_info.get("value"),
                }
            )
            continue

        old_info = old_quotas[code]

        if old_info.get("value") != new_info.get("value"):
            changes.append(
                {
                    "type": "changed",
                    "code": code,
                    "name": new_info.get("name", code),
                    "old_value": old_info.get("value"),
                    "new_value": new_info.get("value"),
                }
            )

        old_usage = old_info.get("usage")
        new_usage = new_info.get("usage")
        if old_usage is not None and new_usage is not None and old_usage != new_usage:
            changes.append(
                {
                    "type": "usage_changed",
                    "code": code,
                    "name": new_info.get("name", code),
                    "old_usage": old_usage,
                    "new_usage": new_usage,
                    "limit": new_info.get("value"),
                }
            )

    for code, old_info in old_quotas.items():
        if code not in new_quotas:
            changes.append(
                {
                    "type": "removed",
                    "code": code,
                    "name": old_info.get("name", code),
                    "old_value": old_info.get("value"),
                    "new_value": None,
                }
            )

    return changes
