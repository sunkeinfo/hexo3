"""
Web 登录密码的哈希与校验（只用标准库，不引入额外依赖）

密码永远不明文保存，config.json 里存的是 PBKDF2-SHA256 的派生值：
    pbkdf2_sha256$<迭代次数>$<salt_b64>$<hash_b64>
"""
import base64
import hashlib
import hmac
import secrets

ALGORITHM = "pbkdf2_sha256"
ITERATIONS = 240_000
SALT_BYTES = 16

# 首次启动时的初始密码。公网部署请第一时间在界面上改掉。
DEFAULT_PASSWORD = "123"
MIN_PASSWORD_LENGTH = 6


def _b64(raw: bytes) -> str:
    return base64.b64encode(raw).decode("ascii")


def _derive(password: str, salt: bytes, iterations: int) -> bytes:
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(SALT_BYTES)
    digest = _derive(password, salt, ITERATIONS)
    return f"{ALGORITHM}${ITERATIONS}${_b64(salt)}${_b64(digest)}"


def verify_password(password: str, stored: str) -> bool:
    """用固定时间比较校验密码；stored 格式非法时返回 False"""
    if not password or not stored:
        return False
    try:
        algorithm, iterations, salt_b64, hash_b64 = stored.split("$")
        if algorithm != ALGORITHM:
            return False
        salt = base64.b64decode(salt_b64)
        expected = base64.b64decode(hash_b64)
        candidate = _derive(password, salt, int(iterations))
    except (ValueError, TypeError):
        return False
    return hmac.compare_digest(candidate, expected)


def validate_new_password(password: str) -> str:
    """返回错误信息；通过校验时返回空字符串"""
    if not password:
        return "新密码不能为空"
    if len(password) < MIN_PASSWORD_LENGTH:
        return f"新密码至少 {MIN_PASSWORD_LENGTH} 位"
    if password == DEFAULT_PASSWORD:
        return "不能继续使用初始密码"
    if password.strip() != password:
        return "新密码首尾不能有空格"
    return ""
