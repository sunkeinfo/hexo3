"""
定时任务调度器

与 Windows 版相比修掉的几个问题：
1. Windows 版 stop() 调用 scheduler.shutdown()，而 APScheduler 关闭后无法再 start()，
   所以"停止 -> 再启动"会抛异常。这里改成调度器常驻、只增删 job。
2. Windows 版改了检查间隔不会重新排程，必须重启进程才生效。这里 apply_interval() 立即生效。
3. Windows 版邮件发送失败时仍然覆盖基线，那次配额变化就永久丢了（而这正是本工具的意义所在）。
   这里发送失败保留旧基线，下一轮重试，超过上限才放弃。
4. 加了执行锁 + coalesce/max_instances，避免一次检查超时后多轮叠加。
5. "是否在监控"持久化到 config，服务重启后自动恢复。
"""
import json
import logging
import os
import tempfile
import threading
from collections import deque
from datetime import datetime
from typing import Any, Dict, Optional

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.interval import IntervalTrigger

from aws_service import EC2QuotaService, compare_quotas, get_monitored_quotas_map
from config import QUOTAS_HISTORY_FILE, config
from email_service import email_service

logger = logging.getLogger(__name__)

JOB_ID = "quota_check"
# 邮件连续发送失败多少轮之后放弃这次变化，避免无限重试
MAX_NOTIFY_ATTEMPTS = 5
# 界面上展示的最近事件条数
EVENT_HISTORY_SIZE = 30


class QuotaMonitor:
    def __init__(self):
        self.scheduler = BackgroundScheduler(
            job_defaults={
                "coalesce": True,        # 错过多次只补一次
                "max_instances": 1,      # 同一时间只跑一个检查
                "misfire_grace_time": 300,
            }
        )
        self._check_lock = threading.Lock()
        self._state_lock = threading.RLock()

        self.last_check_time: Optional[datetime] = None
        self.last_success_time: Optional[datetime] = None
        self.last_quotas: Dict[str, Any] = {}
        self.last_error: Optional[str] = None
        self.check_count = 0
        self.notify_failures = 0
        self.events = deque(maxlen=EVENT_HISTORY_SIZE)

        self._load_last_quotas()

    # ---------- 历史记录 ----------

    def _load_last_quotas(self):
        if not QUOTAS_HISTORY_FILE.exists():
            return
        try:
            with open(QUOTAS_HISTORY_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError) as e:
            logger.error("加载历史配额失败: %s", e)
            return

        monitored = get_monitored_quotas_map()
        # 只保留仍在监控列表里的配额，否则移除监控项会一直报 "removed"
        self.last_quotas = {k: v for k, v in (data.get("quotas") or {}).items() if k in monitored}
        self.check_count = int(data.get("check_count") or 0)

        for field, attr in (("last_check_time", "last_check_time"), ("last_success_time", "last_success_time")):
            raw = data.get(field)
            if raw:
                try:
                    setattr(self, attr, datetime.fromisoformat(raw))
                except ValueError:
                    pass

        logger.info("加载历史配额记录: %d 条", len(self.last_quotas))

    def _save_quotas(self, quotas: Dict[str, Any]):
        data = {
            "quotas": quotas,
            "last_check_time": self.last_check_time.isoformat() if self.last_check_time else None,
            "last_success_time": self.last_success_time.isoformat() if self.last_success_time else None,
            "check_count": self.check_count,
        }
        fd, tmp_name = tempfile.mkstemp(
            dir=str(QUOTAS_HISTORY_FILE.parent), prefix=f".{QUOTAS_HISTORY_FILE.name}.", suffix=".tmp"
        )
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp_name, QUOTAS_HISTORY_FILE)
            logger.info("保存配额记录: %d 条", len(quotas))
        except OSError as e:
            logger.error("保存配额记录失败: %s", e)
            try:
                os.unlink(tmp_name)
            except OSError:
                pass

    def _add_event(self, kind: str, message: str, changes: Optional[list] = None):
        with self._state_lock:
            self.events.appendleft(
                {
                    "time": datetime.now().isoformat(timespec="seconds"),
                    "kind": kind,  # ok | change | error
                    "message": message,
                    "changes": changes or [],
                }
            )

    # ---------- 核心检查 ----------

    def check_quotas(self) -> dict:
        """执行一次配额检查。返回本次结果摘要。"""
        if not self._check_lock.acquire(blocking=False):
            logger.info("上一次检查尚未结束，跳过本次")
            return {"success": False, "skipped": True, "error": "上一次检查仍在进行中"}

        try:
            return self._check_quotas_locked()
        finally:
            self._check_lock.release()

    def _check_quotas_locked(self) -> dict:
        logger.info("开始检查 EC2 配额...")
        with self._state_lock:
            self.check_count += 1
            self.last_check_time = datetime.now()
            self.last_error = None

        if not config.is_configured or not config.has_credentials():
            msg = "配置未完成，跳过检查"
            logger.warning(msg)
            with self._state_lock:
                self.last_error = msg
            self._add_event("error", msg)
            return {"success": False, "error": msg}

        try:
            service = EC2QuotaService.from_config()
            current_quotas = service.get_all_ec2_quotas()
        except Exception as e:  # noqa: BLE001 - 调度线程里必须兜住所有异常
            error = str(e)
            logger.error("检查配额时发生错误: %s", error)
            with self._state_lock:
                self.last_error = error
            self._add_event("error", f"查询配额失败: {error}")
            return {"success": False, "error": error}

        logger.info("获取到 %d 个配额", len(current_quotas))
        baseline = dict(self.last_quotas)
        changes = compare_quotas(baseline, current_quotas) if baseline else []

        if not baseline:
            logger.info("首次检查，建立基线，不发送通知")
            self._add_event("ok", f"建立基线，共 {len(current_quotas)} 个配额")
        elif not changes:
            logger.info("没有检测到配额变化")
            self._add_event("ok", "没有变化")
        else:
            logger.info("检测到 %d 个变化", len(changes))
            if not self._notify(changes, baseline, current_quotas):
                # 通知失败：保留旧基线，下一轮重试同一批变化
                with self._state_lock:
                    self.notify_failures += 1
                    give_up = self.notify_failures >= MAX_NOTIFY_ATTEMPTS
                if give_up:
                    logger.error("邮件连续失败 %d 次，放弃本次变化并推进基线", MAX_NOTIFY_ATTEMPTS)
                    self._add_event("error", f"邮件连续失败 {MAX_NOTIFY_ATTEMPTS} 次，已放弃本次通知", changes)
                    with self._state_lock:
                        self.notify_failures = 0
                else:
                    self._add_event("error", "邮件发送失败，下一轮会重试", changes)
                    return {"success": False, "error": self.last_error, "changes": changes}
            else:
                with self._state_lock:
                    self.notify_failures = 0
                self._add_event("change", f"检测到 {len(changes)} 处变化，已发送邮件", changes)

        with self._state_lock:
            self.last_quotas = current_quotas
            self.last_success_time = datetime.now()
        self._save_quotas(current_quotas)

        return {"success": True, "changes": changes, "quotas_count": len(current_quotas)}

    def _notify(self, changes: list, old_quotas: dict, new_quotas: dict) -> bool:
        try:
            result = email_service.send_quota_change_notification(
                to_email=config.notification_email,
                changes=changes,
                region=config.aws_region,
                old_quotas=old_quotas,
                new_quotas=new_quotas,
            )
        except Exception as e:  # noqa: BLE001
            logger.error("发送通知时异常: %s", e)
            with self._state_lock:
                self.last_error = f"邮件发送异常: {e}"
            return False

        if result.get("success"):
            logger.info("变化通知邮件发送成功")
            return True

        error = result.get("error", "未知错误")
        logger.error("变化通知邮件发送失败: %s", error)
        with self._state_lock:
            self.last_error = f"邮件发送失败: {error}"
        return False

    # ---------- 调度控制 ----------

    def ensure_scheduler_started(self):
        if not self.scheduler.running:
            self.scheduler.start()
            logger.info("调度器已启动")

    @property
    def is_running(self) -> bool:
        return self.scheduler.running and self.scheduler.get_job(JOB_ID) is not None

    def start(self, run_immediately: bool = True):
        """启动周期监控（幂等）"""
        self.ensure_scheduler_started()
        interval = config.check_interval

        self.scheduler.add_job(
            self.check_quotas,
            trigger=IntervalTrigger(minutes=interval),
            id=JOB_ID,
            name="EC2 Quota Check",
            replace_existing=True,
            # 立即跑一次，且不阻塞调用方（Windows 版会让 HTTP 请求等完整一轮检查+发邮件）
            next_run_time=datetime.now() if run_immediately else None,
        )
        config.monitor_enabled = True
        logger.info("配额监控已启动，检查间隔: %d 分钟", interval)

    def stop(self):
        """停止周期监控，但保留调度器本身以便再次启动"""
        if self.scheduler.running and self.scheduler.get_job(JOB_ID):
            self.scheduler.remove_job(JOB_ID)
        config.monitor_enabled = False
        logger.info("配额监控已停止")

    def apply_interval(self):
        """检查间隔变更后立即重新排程"""
        if not self.is_running:
            return
        self.scheduler.reschedule_job(JOB_ID, trigger=IntervalTrigger(minutes=config.check_interval))
        logger.info("检查间隔已更新为 %d 分钟", config.check_interval)

    def reset_baseline(self):
        """清空基线，下一次检查重新建立（改动监控配额列表后有用）"""
        with self._state_lock:
            self.last_quotas = {}
            self.notify_failures = 0
        self._save_quotas({})
        logger.info("配额基线已重置")

    def shutdown(self):
        """进程退出时调用"""
        if self.scheduler.running:
            self.scheduler.shutdown(wait=False)
        email_service.close()
        logger.info("调度器已关闭")

    # ---------- 状态查询 ----------

    def next_run_time(self) -> Optional[str]:
        job = self.scheduler.get_job(JOB_ID) if self.scheduler.running else None
        if job and job.next_run_time:
            return job.next_run_time.isoformat()
        return None

    def get_status(self) -> dict:
        with self._state_lock:
            return {
                "is_running": self.is_running,
                "last_check_time": self.last_check_time.isoformat() if self.last_check_time else None,
                "last_success_time": self.last_success_time.isoformat() if self.last_success_time else None,
                "next_run_time": self.next_run_time(),
                "check_count": self.check_count,
                "last_error": self.last_error,
                "interval_minutes": config.check_interval,
                "is_configured": config.is_configured,
                "credentials_source": config.credentials_source,
                "region": config.aws_region,
                "quotas_count": len(self.last_quotas),
                "notify_failures": self.notify_failures,
            }

    def get_events(self) -> list:
        with self._state_lock:
            return list(self.events)

    def trigger_check(self) -> dict:
        """手动触发一次检查（同步执行，便于界面直接看到结果）"""
        result = self.check_quotas()
        if result.get("success"):
            changes = result.get("changes") or []
            message = f"检查完成，检测到 {len(changes)} 处变化" if changes else "检查完成，没有变化"
            return {"success": True, "message": message, "changes": changes}
        return {"success": False, "error": result.get("error", "检查失败")}


quota_monitor = QuotaMonitor()
