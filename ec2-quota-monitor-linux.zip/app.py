"""
Flask Web 应用 - 提供 Web 界面和 API

与 Windows 版的差异：
- create_app() 工厂模式，便于 gunicorn 加载（见 wsgi.py）
- 强制登录（会话 Cookie，初始密码 123，可在界面上修改，见 auth.py）
- 日志默认输出到 stdout 交给 journald；EQM_LOG_FILE 存在时同时写文件
- 不再把 AWS Secret Key 回传给浏览器
- 改间隔后立即重新排程；新增监控配额编辑、事件时间线、基线重置接口
"""
import atexit
import logging
import os
import signal
import sys
from datetime import timedelta

from flask import Flask, current_app, jsonify, redirect, render_template, request, url_for

from auth import (
    client_ip,
    clear_failures,
    install_auth_gate,
    is_authenticated,
    lockout_remaining,
    login_session,
    logout_session,
    record_failure,
    requires_password,
)
from aws_service import EC2QuotaService, format_quotas_for_display
from config import config
from email_service import email_service
from scheduler import quota_monitor
from security import validate_new_password

logger = logging.getLogger(__name__)

AWS_REGIONS = [
    ("us-east-1", "美国东部 (弗吉尼亚北部)"),
    ("us-east-2", "美国东部 (俄亥俄)"),
    ("us-west-1", "美国西部 (加利福尼亚北部)"),
    ("us-west-2", "美国西部 (俄勒冈)"),
    ("af-south-1", "非洲 (开普敦)"),
    ("ap-east-1", "亚太地区 (香港)"),
    ("ap-south-1", "亚太地区 (孟买)"),
    ("ap-south-2", "亚太地区 (海得拉巴)"),
    ("ap-northeast-1", "亚太地区 (东京)"),
    ("ap-northeast-2", "亚太地区 (首尔)"),
    ("ap-northeast-3", "亚太地区 (大阪)"),
    ("ap-southeast-1", "亚太地区 (新加坡)"),
    ("ap-southeast-2", "亚太地区 (悉尼)"),
    ("ap-southeast-3", "亚太地区 (雅加达)"),
    ("ca-central-1", "加拿大 (中部)"),
    ("eu-central-1", "欧洲 (法兰克福)"),
    ("eu-central-2", "欧洲 (苏黎世)"),
    ("eu-west-1", "欧洲 (爱尔兰)"),
    ("eu-west-2", "欧洲 (伦敦)"),
    ("eu-west-3", "欧洲 (巴黎)"),
    ("eu-north-1", "欧洲 (斯德哥尔摩)"),
    ("eu-south-1", "欧洲 (米兰)"),
    ("me-south-1", "中东 (巴林)"),
    ("sa-east-1", "南美洲 (圣保罗)"),
]


# ==================== 日志 ====================

def setup_logging():
    level = getattr(logging, os.environ.get("EQM_LOG_LEVEL", "INFO").upper(), logging.INFO)
    handlers = [logging.StreamHandler(sys.stdout)]

    log_file = os.environ.get("EQM_LOG_FILE", "").strip()
    if log_file:
        try:
            handlers.append(logging.FileHandler(log_file, encoding="utf-8"))
        except OSError as e:
            print(f"无法写入日志文件 {log_file}: {e}", file=sys.stderr)

    root = logging.getLogger()
    if root.handlers:  # gunicorn reload 时避免重复添加
        return
    logging.basicConfig(
        level=level,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        handlers=handlers,
    )
    # apscheduler 的 INFO 日志比较吵，降一级
    logging.getLogger("apscheduler.executors.default").setLevel(logging.WARNING)


# ==================== 应用 ====================

def create_app() -> Flask:
    setup_logging()

    app = Flask(__name__)
    app.json.ensure_ascii = False

    # 会话签名密钥持久化在 config.json，重启后已登录的浏览器不用重新登录
    app.secret_key = config.session_secret
    app.permanent_session_lifetime = timedelta(days=int(os.environ.get("EQM_SESSION_DAYS", "7")))
    app.config.update(
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        # 走 HTTPS 时把 Cookie 标记为 Secure：EQM_COOKIE_SECURE=1
        SESSION_COOKIE_SECURE=os.environ.get("EQM_COOKIE_SECURE") == "1",
    )

    if os.environ.get("EQM_TRUST_PROXY") == "1":
        # 置于 Nginx 之后时，让 request.remote_addr / url_for 反映真实来源
        from werkzeug.middleware.proxy_fix import ProxyFix

        app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)

    register_routes(app)
    install_auth_gate(app)

    quota_monitor.ensure_scheduler_started()
    if config.monitor_enabled and config.is_configured and config.has_credentials():
        logger.info("检测到上次处于监控状态，自动恢复监控")
        quota_monitor.start(run_immediately=True)
    elif config.monitor_enabled:
        logger.warning("配置不完整，未能自动恢复监控")

    atexit.register(quota_monitor.shutdown)
    # gunicorn 自己管理 SIGTERM/SIGINT（worker 优雅退出时 atexit 会跑），不要抢它的处理器
    if not os.environ.get("SERVER_SOFTWARE", "").startswith("gunicorn"):
        _install_signal_handlers()

    if config.is_default_password:
        logger.warning("Web 登录仍在使用初始密码 123，请登录后立刻修改！")
    if os.environ.get("EQM_COOKIE_SECURE") != "1":
        logger.info("会话 Cookie 未标记 Secure：公网访问请套 HTTPS 并设置 EQM_COOKIE_SECURE=1")

    return app


def _install_signal_handlers():
    """systemd stop 会发 SIGTERM，确保调度器干净退出"""

    def handler(signum, frame):  # noqa: ARG001
        logger.info("收到信号 %s，正在退出", signum)
        quota_monitor.shutdown()
        sys.exit(0)

    for sig in (signal.SIGTERM, signal.SIGINT):
        try:
            signal.signal(sig, handler)
        except ValueError:
            # 非主线程（例如某些 WSGI 容器）里无法注册，忽略
            pass


def register_routes(app: Flask):  # noqa: C901 - 路由集中注册，长度可接受
    # ---------- 页面 ----------

    @app.route("/")
    def index():
        return render_template("index.html")

    @app.route("/healthz")
    def healthz():
        """给 systemd / 反向代理 / 监控用的探针，不需要登录"""
        return jsonify(
            {
                "status": "ok",
                "monitoring": quota_monitor.is_running,
                "configured": config.is_configured,
            }
        )

    # ---------- 登录 ----------

    @app.route("/login", methods=["GET", "POST"])
    def login():
        next_url = request.args.get("next") or request.form.get("next") or "/"
        # 只允许跳回本站路径，避免开放重定向
        if not next_url.startswith("/") or next_url.startswith("//"):
            next_url = "/"

        if is_authenticated():
            return redirect(next_url)

        ip = client_ip()

        if request.method == "GET":
            return render_template("login.html", error="", next_url=next_url, locked=lockout_remaining(ip))

        wait = lockout_remaining(ip)
        if wait > 0:
            logger.warning("IP %s 处于锁定期，拒绝登录尝试", ip)
            return (
                render_template(
                    "login.html",
                    error=f"尝试次数过多，请 {wait} 秒后再试",
                    next_url=next_url,
                    locked=wait,
                ),
                429,
            )

        password = request.form.get("password") or ""
        if not config.verify_web_password(password):
            record_failure(ip)
            return (
                render_template("login.html", error="密码不正确", next_url=next_url, locked=0),
                401,
            )

        clear_failures(ip)
        login_session()
        logger.info("登录成功（IP %s）", ip)
        return redirect(next_url)

    @app.route("/logout", methods=["GET", "POST"])
    def logout():
        logout_session()
        return redirect(url_for("login"))

    @app.route("/api/config/password", methods=["POST"])
    @requires_password
    def change_password():
        """修改 Web 登录密码；requires_password 已校验过当前密码"""
        data = request.get_json(silent=True) or {}
        new_password = data.get("new_password") or ""
        confirm = data.get("confirm_password")

        error = validate_new_password(new_password)
        if error:
            return jsonify({"success": False, "error": error})
        if confirm is not None and confirm != new_password:
            return jsonify({"success": False, "error": "两次输入的新密码不一致"})

        config.set_web_password(new_password)
        # 轮换会话密钥：其它浏览器/设备上的旧登录状态立即失效，只保留当前这个
        current_app.secret_key = config.rotate_session_secret()
        login_session()
        logger.info("Web 登录密码已修改（IP %s）", client_ip())
        return jsonify({"success": True, "message": "密码已修改"})

    # ---------- 配置 ----------

    @app.route("/api/config", methods=["GET"])
    def get_config():
        return jsonify({"success": True, "config": config.to_dict(safe=True)})

    @app.route("/api/config/aws", methods=["POST"])
    def update_aws_config():
        try:
            data = request.get_json(silent=True) or {}
            source = "iam_role" if data.get("credentials_source") == "iam_role" else "keys"
            access_key = (data.get("aws_access_key") or "").strip()
            secret_key = (data.get("aws_secret_key") or "").strip()
            region = (data.get("aws_region") or config.aws_region).strip()

            config.credentials_source = source

            if source == "keys":
                # 留空表示沿用已保存的值
                if access_key:
                    config.aws_access_key = access_key
                if secret_key:
                    config.aws_secret_key = secret_key
                if not config.aws_access_key:
                    return jsonify({"success": False, "error": "AWS Access Key 不能为空"})
                if not config.aws_secret_key:
                    return jsonify({"success": False, "error": "AWS Secret Key 不能为空"})

            config.aws_region = region

            old_interval = config.check_interval
            if data.get("check_interval") is not None:
                try:
                    config.check_interval = int(data["check_interval"])
                except (TypeError, ValueError):
                    return jsonify({"success": False, "error": "检查间隔必须是整数（分钟）"})

            if config.has_credentials():
                config.set_configured(True)

            if config.check_interval != old_interval:
                quota_monitor.apply_interval()

            logger.info("AWS 配置已更新（凭证来源: %s, 区域: %s）", source, config.aws_region)
            return jsonify({"success": True, "message": "AWS 配置已保存", "config": config.to_dict()})
        except Exception as e:  # noqa: BLE001
            logger.exception("更新 AWS 配置失败")
            return jsonify({"success": False, "error": str(e)})

    @app.route("/api/config/email", methods=["POST"])
    def update_email_config():
        try:
            data = request.get_json(silent=True) or {}
            email = (data.get("notification_email") or "").strip()
            if not email or "@" not in email:
                return jsonify({"success": False, "error": "请输入有效的通知邮箱"})

            config.notification_email = email

            api_key = (data.get("email_api_key") or "").strip()
            if api_key:
                config.email_api_key = api_key

            logger.info("邮箱配置已更新")
            return jsonify({"success": True, "message": "邮箱配置已保存"})
        except Exception as e:  # noqa: BLE001
            logger.exception("更新邮箱配置失败")
            return jsonify({"success": False, "error": str(e)})

    @app.route("/api/config/quotas", methods=["POST"])
    def update_monitored_quotas():
        """更新要监控的配额列表：{"quotas": {"L-1216C47A": "名称", ...}}"""
        try:
            data = request.get_json(silent=True) or {}
            quotas = data.get("quotas")
            if not isinstance(quotas, dict) or not quotas:
                return jsonify({"success": False, "error": "请提供至少一个配额（代码 -> 名称）"})

            config.monitored_quotas = quotas
            # 监控项变了，旧基线里多余/缺失的项会被误判成 removed/added
            quota_monitor.reset_baseline()

            logger.info("监控配额列表已更新，共 %d 项，基线已重置", len(config.monitored_quotas))
            return jsonify(
                {
                    "success": True,
                    "message": f"已更新监控配额（{len(config.monitored_quotas)} 项），基线已重置",
                    "quotas": config.monitored_quotas,
                }
            )
        except ValueError as e:
            return jsonify({"success": False, "error": str(e)})
        except Exception as e:  # noqa: BLE001
            logger.exception("更新监控配额失败")
            return jsonify({"success": False, "error": str(e)})

    # ---------- 测试 ----------

    @app.route("/api/test-aws", methods=["POST"])
    def test_aws():
        try:
            data = request.get_json(silent=True) or {}
            source = data.get("credentials_source") or config.credentials_source
            use_iam_role = source == "iam_role"

            access_key = "" if use_iam_role else ((data.get("aws_access_key") or "").strip() or config.aws_access_key)
            secret_key = "" if use_iam_role else ((data.get("aws_secret_key") or "").strip() or config.aws_secret_key)
            region = (data.get("aws_region") or config.aws_region).strip()

            if not use_iam_role and not (access_key and secret_key):
                return jsonify({"success": False, "error": "请先填写 AWS 凭证，或改用 IAM 角色"})

            service = EC2QuotaService(
                access_key=access_key,
                secret_key=secret_key,
                region=region,
                use_iam_role=use_iam_role,
            )
            success, message = service.test_connection()
            return jsonify({"success": success, "message": message, "error": None if success else message})
        except Exception as e:  # noqa: BLE001
            logger.exception("测试 AWS 连接失败")
            return jsonify({"success": False, "error": str(e)})

    @app.route("/api/test-email", methods=["POST"])
    def test_email():
        try:
            data = request.get_json(silent=True) or {}
            email = (data.get("notification_email") or "").strip() or config.notification_email
            if not email:
                return jsonify({"success": False, "error": "请先配置通知邮箱"})
            return jsonify(email_service.send_test_email(email))
        except Exception as e:  # noqa: BLE001
            logger.exception("测试邮件发送失败")
            return jsonify({"success": False, "error": str(e)})

    # ---------- 配额 ----------

    @app.route("/api/quotas", methods=["GET"])
    def get_quotas():
        """默认返回上次检查的缓存结果；?live=1 时实时向 AWS 查询"""
        live = request.args.get("live") in ("1", "true", "yes")

        if not live:
            quotas = format_quotas_for_display(quota_monitor.last_quotas)
            return jsonify(
                {
                    "success": True,
                    "quotas": quotas,
                    "region": config.aws_region,
                    "count": len(quotas),
                    "cached": True,
                    "error": None if quotas else "暂无数据，请先执行一次检查",
                }
            )

        if not config.is_configured or not config.has_credentials():
            return jsonify({"success": False, "error": "请先完成配置"})

        try:
            quotas = format_quotas_for_display(EC2QuotaService.from_config().get_all_ec2_quotas())
            return jsonify(
                {
                    "success": True,
                    "quotas": quotas,
                    "region": config.aws_region,
                    "count": len(quotas),
                    "cached": False,
                }
            )
        except Exception as e:  # noqa: BLE001
            logger.error("获取配额失败: %s", e)
            return jsonify({"success": False, "error": str(e)})

    @app.route("/api/quotas/available", methods=["GET"])
    def list_available_quotas():
        """列出该区域所有 EC2 配额，方便挑选监控项"""
        if not config.is_configured or not config.has_credentials():
            return jsonify({"success": False, "error": "请先完成配置"})
        try:
            quotas = EC2QuotaService.from_config().list_ec2_quotas(request.args.get("q", ""))
            return jsonify({"success": True, "quotas": quotas, "count": len(quotas)})
        except Exception as e:  # noqa: BLE001
            logger.error("列出配额失败: %s", e)
            return jsonify({"success": False, "error": str(e)})

    # ---------- 监控控制 ----------

    @app.route("/api/status", methods=["GET"])
    def get_status():
        return jsonify({"success": True, "status": quota_monitor.get_status()})

    @app.route("/api/events", methods=["GET"])
    def get_events():
        return jsonify({"success": True, "events": quota_monitor.get_events()})

    @app.route("/api/monitor/start", methods=["POST"])
    def start_monitor():
        try:
            if not config.is_configured or not config.has_credentials():
                return jsonify({"success": False, "error": "请先完成配置"})
            quota_monitor.start()
            return jsonify({"success": True, "message": "监控已启动，首轮检查正在后台执行"})
        except Exception as e:  # noqa: BLE001
            logger.exception("启动监控失败")
            return jsonify({"success": False, "error": str(e)})

    @app.route("/api/monitor/stop", methods=["POST"])
    def stop_monitor():
        try:
            quota_monitor.stop()
            return jsonify({"success": True, "message": "监控已停止"})
        except Exception as e:  # noqa: BLE001
            logger.exception("停止监控失败")
            return jsonify({"success": False, "error": str(e)})

    @app.route("/api/monitor/check", methods=["POST"])
    def trigger_check():
        try:
            if not config.is_configured or not config.has_credentials():
                return jsonify({"success": False, "error": "请先完成配置"})
            return jsonify(quota_monitor.trigger_check())
        except Exception as e:  # noqa: BLE001
            logger.exception("手动检查失败")
            return jsonify({"success": False, "error": str(e)})

    @app.route("/api/monitor/reset-baseline", methods=["POST"])
    def reset_baseline():
        try:
            quota_monitor.reset_baseline()
            return jsonify({"success": True, "message": "基线已重置，下次检查将重新建立"})
        except Exception as e:  # noqa: BLE001
            logger.exception("重置基线失败")
            return jsonify({"success": False, "error": str(e)})

    @app.route("/api/regions", methods=["GET"])
    def get_regions():
        return jsonify(
            {
                "success": True,
                "regions": [{"value": value, "label": label} for value, label in AWS_REGIONS],
            }
        )

    # ---------- 错误处理 ----------

    @app.errorhandler(404)
    def not_found(error):  # noqa: ARG001
        return jsonify({"success": False, "error": "资源未找到"}), 404

    @app.errorhandler(500)
    def internal_error(error):  # noqa: ARG001
        logger.exception("服务器内部错误")
        return jsonify({"success": False, "error": "服务器内部错误"}), 500


if __name__ == "__main__":
    # 仅用于本地调试；生产请用 gunicorn（见 run.sh / systemd unit）
    host = os.environ.get("EQM_HOST", "127.0.0.1")
    port = int(os.environ.get("EQM_PORT", "5000"))
    create_app().run(host=host, port=port, debug=False, use_reloader=False)
