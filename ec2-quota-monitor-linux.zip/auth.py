"""
Web 登录（会话 Cookie）

这套东西是为"公网直接访问"准备的：界面里能读写 AWS 凭证，
所以任何未登录请求都必须被拦住。

- 单用户，只有密码，没有用户名
- 初始密码 123（见 security.DEFAULT_PASSWORD），登录后在界面上修改
- 密码以 PBKDF2 哈希存在 config.json，不存明文
- 登录失败按来源 IP 限速，防止公网上被暴力猜密码
- 会话签名密钥持久化，服务重启不会把人踢下线
"""
import logging
import os
import threading
import time
from collections import defaultdict, deque
from functools import wraps

from flask import g, jsonify, redirect, request, session, url_for

from config import config

logger = logging.getLogger(__name__)

SESSION_KEY = "authed"
# 免登录的路径（健康探针给外部监控用，登录页本身自然也要放行）
PUBLIC_ENDPOINTS = {"login", "logout", "healthz", "static"}

# 失败限速：同一 IP 在 WINDOW 秒内失败 MAX_FAILURES 次，则锁定 LOCKOUT 秒
MAX_FAILURES = int(os.environ.get("EQM_LOGIN_MAX_FAILURES", "5"))
FAILURE_WINDOW = int(os.environ.get("EQM_LOGIN_WINDOW", "300"))
LOCKOUT_SECONDS = int(os.environ.get("EQM_LOGIN_LOCKOUT", "300"))

_failures = defaultdict(deque)
_failures_lock = threading.Lock()


def client_ip() -> str:
    """取来源 IP；置于反向代理之后时用 X-Forwarded-For 的第一跳"""
    if os.environ.get("EQM_TRUST_PROXY") == "1":
        forwarded = request.headers.get("X-Forwarded-For", "")
        if forwarded:
            return forwarded.split(",")[0].strip()
    return request.remote_addr or "unknown"


def _prune(ip: str, now: float):
    bucket = _failures[ip]
    while bucket and now - bucket[0] > FAILURE_WINDOW:
        bucket.popleft()
    if not bucket:
        _failures.pop(ip, None)


def lockout_remaining(ip: str) -> int:
    """返回还需等待的秒数，0 表示未被锁定"""
    now = time.time()
    with _failures_lock:
        _prune(ip, now)
        bucket = _failures.get(ip)
        if not bucket or len(bucket) < MAX_FAILURES:
            return 0
        remaining = int(LOCKOUT_SECONDS - (now - bucket[-1]))
        return max(remaining, 0)


def record_failure(ip: str):
    now = time.time()
    with _failures_lock:
        _prune(ip, now)
        _failures[ip].append(now)
        count = len(_failures[ip])
    logger.warning("登录失败（IP %s，窗口内第 %d 次）", ip, count)
    if count >= MAX_FAILURES:
        logger.warning("IP %s 登录失败过多，锁定 %d 秒", ip, LOCKOUT_SECONDS)


def clear_failures(ip: str):
    with _failures_lock:
        _failures.pop(ip, None)


def is_authenticated() -> bool:
    return bool(session.get(SESSION_KEY))


def login_session():
    session.clear()
    session[SESSION_KEY] = True
    session.permanent = True


def logout_session():
    session.clear()


def wants_json() -> bool:
    return request.path.startswith("/api/") or "application/json" in (request.headers.get("Accept") or "")


def install_auth_gate(app):
    """全局拦截：除 PUBLIC_ENDPOINTS 外一律要求登录"""

    @app.before_request
    def _require_login():
        if request.endpoint in PUBLIC_ENDPOINTS:
            return None
        if is_authenticated():
            g.authed = True
            return None
        if wants_json():
            return jsonify({"success": False, "error": "未登录", "need_login": True}), 401
        return redirect(url_for("login", next=request.path))


def requires_password(view):
    """给改密码这类敏感操作用：必须再确认一次当前密码"""

    @wraps(view)
    def wrapper(*args, **kwargs):
        data = request.get_json(silent=True) or {}
        if not config.verify_web_password(data.get("current_password") or ""):
            return jsonify({"success": False, "error": "当前密码不正确"}), 403
        return view(*args, **kwargs)

    return wrapper
