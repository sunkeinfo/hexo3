"""gunicorn 配置。可用环境变量覆盖 bind 地址。"""
import os

# 默认对外监听（界面有登录密码保护）。只想本机访问就设 EQM_BIND=127.0.0.1:5000。
# 公网使用请尽快套 HTTPS：见 deploy/nginx.conf.example
bind = os.environ.get("EQM_BIND", "0.0.0.0:5000")

# 必须为 1：多 worker 会有多个调度器，重复发邮件
workers = 1
threads = int(os.environ.get("EQM_THREADS", "4"))
worker_class = "gthread"

timeout = int(os.environ.get("EQM_TIMEOUT", "120"))
graceful_timeout = 30
keepalive = 5

# 交给 journald 收集
accesslog = os.environ.get("EQM_ACCESS_LOG", "-")
errorlog = "-"
loglevel = os.environ.get("EQM_LOG_LEVEL", "info").lower()
# 健康探针不刷日志
access_log_format = '%(h)s "%(r)s" %(s)s %(b)s %(M)sms'

proc_name = "ec2-quota-monitor"
preload_app = False
