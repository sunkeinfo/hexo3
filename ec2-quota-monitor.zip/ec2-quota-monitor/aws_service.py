"""
AWS EC2 Quota 查询模块
负责查询 AWS EC2 服务配额
"""
import boto3
from botocore.exceptions import ClientError, NoCredentialsError
from typing import Dict, List, Optional
import logging

logger = logging.getLogger(__name__)

from config import config as _config

def get_monitored_quotas_map() -> dict:
    """从配置文件读取监控配额列表"""
    return _config.monitored_quotas

# 保持向后兼容，供 scheduler 过滤用
MONITORED_QUOTAS = property(get_monitored_quotas_map)


class EC2QuotaService:
    """EC2 配额查询服务"""
    
    def __init__(self, access_key: str, secret_key: str, region: str = "us-east-1"):
        self.access_key = access_key
        self.secret_key = secret_key
        self.region = region
        self._client = None
    
    def _get_client(self):
        """获取 Service Quotas 客户端"""
        if self._client is None:
            self._client = boto3.client(
                'service-quotas',
                aws_access_key_id=self.access_key,
                aws_secret_access_key=self.secret_key,
                region_name=self.region
            )
        return self._client
    
    def _get_ec2_client(self):
        """获取 EC2 客户端"""
        return boto3.client(
            'ec2',
            aws_access_key_id=self.access_key,
            aws_secret_access_key=self.secret_key,
            region_name=self.region
        )
    
    def get_monitored_quotas(self) -> Dict[str, dict]:
        """
        获取需要监控的配额（只获取指定的两个配额）
        
        Returns:
            Dict[str, dict]: 配额代码到配额信息的映射
        """
        quotas = {}
        client = self._get_client()
        
        try:
            # 直接获取指定的配额
            for quota_code, quota_name in get_monitored_quotas_map().items():
                try:
                    response = client.get_service_quota(
                        ServiceCode='ec2',
                        QuotaCode=quota_code
                    )
                    quota = response['Quota']
                    quotas[quota_code] = {
                        'code': quota_code,
                        'name': quota['QuotaName'],
                        'value': quota['Value'],
                        'unit': quota.get('Unit', 'None'),
                        'adjustable': quota.get('Adjustable', False),
                        'global_quota': quota.get('GlobalQuota', False),
                        'usage': None
                    }
                except ClientError as e:
                    logger.warning(f"无法获取配额 {quota_code}: {e}")
                    continue
            
        except ClientError as e:
            logger.error(f"获取配额失败: {e}")
            raise
        except NoCredentialsError:
            logger.error("AWS 凭证无效")
            raise
        
        return quotas
    
    def get_all_ec2_quotas(self) -> Dict[str, dict]:
        """
        获取所有 EC2 相关配额（只返回监控的配额）
        
        Returns:
            Dict[str, dict]: 配额代码到配额信息的映射
        """
        return self.get_monitored_quotas()
    
    def _get_quota_usage(self) -> Dict[str, float]:
        """
        获取配额使用量
        
        Returns:
            Dict[str, float]: 配额代码到使用量的映射
        """
        usage = {}
        
        try:
            ec2_client = self._get_ec2_client()
            
            # 获取运行中的实例数量
            response = ec2_client.describe_instances(
                Filters=[{'Name': 'instance-state-name', 'Values': ['running']}]
            )
            
            # 按实例类型统计
            instance_counts = {}
            for reservation in response.get('Reservations', []):
                for instance in reservation.get('Instances', []):
                    instance_type = instance.get('InstanceType', 'unknown')
                    instance_counts[instance_type] = instance_counts.get(instance_type, 0) + 1
            
            # 计算总使用量
            total_running = sum(instance_counts.values())
            
            # 映射到配额代码
            usage['L-0263EA10-DFE1-4F0E-8A5D-6B1E2F9D5C3A'] = total_running
            
            # 获取 Elastic IP 使用量
            eip_response = ec2_client.describe_addresses()
            usage['L-0263EA10-DFE1-4F0E-8A5D-6B1E2F9D5C3A'] = len(eip_response.get('Addresses', []))
            
        except Exception as e:
            logger.warning(f"获取使用量失败: {e}")
        
        return usage
    
    def get_quota_by_code(self, quota_code: str) -> Optional[dict]:
        """
        根据配额代码获取单个配额
        
        Args:
            quota_code: 配额代码
            
        Returns:
            Optional[dict]: 配额信息，如果不存在返回 None
        """
        client = self._get_client()
        
        try:
            response = client.get_service_quota(
                ServiceCode='ec2',
                QuotaCode=quota_code
            )
            quota = response['Quota']
            return {
                'code': quota['QuotaCode'],
                'name': quota['QuotaName'],
                'value': quota['Value'],
                'unit': quota.get('Unit', 'None'),
                'adjustable': quota.get('Adjustable', False),
                'global_quota': quota.get('GlobalQuota', False)
            }
        except ClientError as e:
            if e.response['Error']['Code'] == 'NoSuchResourceException':
                return None
            raise
    
    def test_connection(self) -> tuple[bool, str]:
        """
        测试 AWS 连接
        
        Returns:
            tuple[bool, str]: (是否成功, 消息)
        """
        try:
            client = self._get_client()
            # 尝试列出服务配额来验证连接
            response = client.list_service_quotas(ServiceCode='ec2', MaxResults=1)
            return True, f"连接成功，区域: {self.region}"
        except NoCredentialsError:
            return False, "AWS 凭证无效"
        except ClientError as e:
            error_code = e.response['Error']['Code']
            if error_code == 'InvalidClientTokenId':
                return False, "AWS Access Key 无效"
            elif error_code == 'SignatureDoesNotMatch':
                return False, "AWS Secret Key 无效"
            elif error_code == 'UnauthorizedOperation':
                return False, "没有权限访问 Service Quotas"
            else:
                return False, f"连接失败: {e.response['Error']['Message']}"
        except Exception as e:
            return False, f"连接失败: {str(e)}"


def format_quotas_for_display(quotas: Dict[str, dict]) -> List[dict]:
    """
    格式化配额信息用于显示
    
    Args:
        quotas: 配额字典
        
    Returns:
        List[dict]: 格式化后的配额列表
    """
    result = []
    for code, info in quotas.items():
        result.append({
            'code': code,
            'name': info['name'],
            'limit': info['value'],
            'usage': info.get('usage', 'N/A'),
            'unit': info.get('unit', ''),
            'adjustable': info.get('adjustable', False)
        })
    
    # 按名称排序
    result.sort(key=lambda x: x['name'])
    return result


def compare_quotas(old_quotas: Dict[str, dict], new_quotas: Dict[str, dict]) -> List[dict]:
    """
    比较两次配额的变化
    
    Args:
        old_quotas: 旧配额
        new_quotas: 新配额
        
    Returns:
        List[dict]: 变化列表
    """
    changes = []
    
    # 检查新增的配额
    for code, new_info in new_quotas.items():
        if code not in old_quotas:
            changes.append({
                'type': 'added',
                'code': code,
                'name': new_info['name'],
                'old_value': None,
                'new_value': new_info['value']
            })
            continue
        
        old_info = old_quotas[code]
        
        # 检查值变化
        if old_info['value'] != new_info['value']:
            changes.append({
                'type': 'changed',
                'code': code,
                'name': new_info['name'],
                'old_value': old_info['value'],
                'new_value': new_info['value']
            })
        
        # 检查使用量变化
        old_usage = old_info.get('usage')
        new_usage = new_info.get('usage')
        if old_usage != new_usage and old_usage is not None and new_usage is not None:
            changes.append({
                'type': 'usage_changed',
                'code': code,
                'name': new_info['name'],
                'old_usage': old_usage,
                'new_usage': new_usage,
                'limit': new_info['value']
            })
    
    # 检查删除的配额
    for code, old_info in old_quotas.items():
        if code not in new_quotas:
            changes.append({
                'type': 'removed',
                'code': code,
                'name': old_info['name'],
                'old_value': old_info['value'],
                'new_value': None
            })
    
    return changes