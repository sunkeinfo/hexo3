"""
配置管理模块
所有配置明文保存在 data/config.json，方便手动编辑
"""
import json
from pathlib import Path

DATA_DIR = Path(__file__).parent / "data"
DATA_DIR.mkdir(exist_ok=True)

CONFIG_FILE = DATA_DIR / "config.json"
QUOTAS_HISTORY_FILE = DATA_DIR / "quotas_history.json"

DEFAULT_CONFIG = {
    "aws_access_key": "",
    "aws_secret_key": "",
    "aws_region": "us-east-1",
    "check_interval": 10,
    "monitored_quotas": {
        "L-34B43A08": "All Standard (A, C, D, H, I, M, R, T, Z) Spot Instance Requests",
        "L-1216C47A": "Running On-Demand Standard (A, C, D, H, I, M, R, T, Z) instances"
    },
    "email": {
        "api_url": "https://api.pingram.io/send",
        "api_key": "pingram_sk_eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiJrZXlfOTRjZDJlOGFkOTYwMzU1OTJlOTAzZWI5NmU5ZDg5M2IiLCJ2ZXJzaW9uIjoxLCJhY2NvdW50SWQiOiIwOTdidWx1bGJkamZtOTY5eHJtcmlqaXo0MyIsImtleVR5cGUiOiJzZWNyZXQiLCJlbnZpcm9ubWVudElkIjoiMDk3YnVsdWxiZGpmbTk2OXhybXJpaml6NDMifQ.iNezQ3sgydRwDtWBQsYTITkfM9nEPeV5eS8VXBYYmDg",
        "template_id": "awsdo_com",
        "notification_type": "awsdo_com_notification",
        "to_address": ""
    },
    "is_configured": False
}


class Config:
    def __init__(self):
        self._config = self._load_config()

    def _load_config(self) -> dict:
        if CONFIG_FILE.exists():
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            # 补全缺失的新字段
            for key, val in DEFAULT_CONFIG.items():
                if key not in data:
                    data[key] = val
            if "email" not in data:
                data["email"] = DEFAULT_CONFIG["email"]
            else:
                for k, v in DEFAULT_CONFIG["email"].items():
                    if k not in data["email"]:
                        data["email"][k] = v
            return data
        return dict(DEFAULT_CONFIG)

    def _save_config(self):
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(self._config, f, indent=2, ensure_ascii=False)

    # AWS
    @property
    def aws_access_key(self) -> str:
        return self._config.get("aws_access_key", "")

    @aws_access_key.setter
    def aws_access_key(self, value: str):
        self._config["aws_access_key"] = value
        self._save_config()

    @property
    def aws_secret_key(self) -> str:
        return self._config.get("aws_secret_key", "")

    @aws_secret_key.setter
    def aws_secret_key(self, value: str):
        self._config["aws_secret_key"] = value
        self._save_config()

    @property
    def aws_region(self) -> str:
        return self._config.get("aws_region", "us-east-1")

    @aws_region.setter
    def aws_region(self, value: str):
        self._config["aws_region"] = value
        self._save_config()

    @property
    def check_interval(self) -> int:
        return self._config.get("check_interval", 10)

    @check_interval.setter
    def check_interval(self, value: int):
        self._config["check_interval"] = value
        self._save_config()

    # 监控配额列表
    @property
    def monitored_quotas(self) -> dict:
        return self._config.get("monitored_quotas", DEFAULT_CONFIG["monitored_quotas"])

    # 邮件配置
    @property
    def email_api_url(self) -> str:
        return self._config["email"].get("api_url", DEFAULT_CONFIG["email"]["api_url"])

    @property
    def email_api_key(self) -> str:
        return self._config["email"].get("api_key", "")

    @property
    def email_template_id(self) -> str:
        return self._config["email"].get("template_id", DEFAULT_CONFIG["email"]["template_id"])

    @property
    def email_notification_type(self) -> str:
        return self._config["email"].get("notification_type", DEFAULT_CONFIG["email"]["notification_type"])

    @property
    def notification_email(self) -> str:
        return self._config["email"].get("to_address", "")

    @notification_email.setter
    def notification_email(self, value: str):
        self._config["email"]["to_address"] = value
        self._save_config()

    @property
    def is_configured(self) -> bool:
        return self._config.get("is_configured", False)

    def set_configured(self, value: bool):
        self._config["is_configured"] = value
        self._save_config()

    def to_dict(self, safe: bool = True) -> dict:
        return {
            "aws_access_key": self.aws_access_key,
            "aws_secret_key": self.aws_secret_key,
            "aws_region": self.aws_region,
            "check_interval": self.check_interval,
            "notification_email": self.notification_email,
            "is_configured": self.is_configured
        }


config = Config()
