@echo off
:: EC2 Quota Monitor - Windows 服务安装脚本
:: 需要以管理员身份运行

echo ============================================
echo   EC2 Quota Monitor - Windows 服务安装
echo ============================================
echo.

:: 检查管理员权限
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [错误] 请以管理员身份运行此脚本！
    echo 右键点击此文件，选择"以管理员身份运行"
    pause
    exit /b 1
)

:: 设置变量
set "INSTALL_DIR=%~dp0"
set "PYTHON_EXE=py"
set "SERVICE_NAME=EC2QuotaMonitor"
set "SERVICE_DISPLAY_NAME=EC2 Quota Monitor"
set "SERVICE_DESCRIPTION=AWS EC2 配额监控服务 - 定时检查配额变化并发送邮件通知"

echo [信息] 安装目录: %INSTALL_DIR%
echo.

:: 检查 Python
echo [检查] 正在检查 Python...
%PYTHON_EXE% --version >nul 2>&1
if %errorLevel% neq 0 (
    echo [错误] 未找到 Python，请先安装 Python
    pause
    exit /b 1
)
echo [成功] Python 已安装
echo.

:: 检查 pip
echo [检查] 正在检查 pip...
%PYTHON_EXE% -m pip --version >nul 2>&1
if %errorLevel% neq 0 (
    echo [错误] 未找到 pip
    pause
    exit /b 1
)
echo [成功] pip 已安装
echo.

:: 安装 Python 依赖
echo [安装] 正在安装 Python 依赖...
cd /d "%INSTALL_DIR%"
%PYTHON_EXE% -m pip install -r requirements.txt -q
if %errorLevel% neq 0 (
    echo [警告] 依赖安装可能存在问题，继续安装...
)
echo [成功] Python 依赖安装完成
echo.

:: 检查 NSSM
echo [检查] 正在检查 NSSM...
where nssm >nul 2>&1
if %errorLevel% neq 0 (
    echo [信息] NSSM 未安装，正在尝试下载...
    
    :: 创建临时目录
    if not exist "%INSTALL_DIR%temp" mkdir "%INSTALL_DIR%temp"
    
    :: 下载 NSSM
    echo [下载] 正在下载 NSSM...
    curl -L -o "%INSTALL_DIR%temp\nssm.zip" "https://nssm.cc/release/nssm-2.24.zip"
    
    if exist "%INSTALL_DIR%temp\nssm.zip" (
        echo [解压] 正在解压 NSSM...
        %PYTHON_EXE% -c "import zipfile; zipfile.ZipFile(r'%INSTALL_DIR%temp\nssm.zip').extractall(r'%INSTALL_DIR%temp')"
        
        :: 复制 NSSM 到系统目录
        copy "%INSTALL_DIR%temp\nssm-2.24\win64\nssm.exe" "C:\Windows\nssm.exe" >nul 2>&1
        if %errorLevel% neq 0 (
            echo [警告] 无法复制 NSSM 到系统目录，请手动安装 NSSM
            echo 你可以从 https://nssm.cc/download 下载 NSSM
        ) else (
            echo [成功] NSSM 安装完成
        )
        
        :: 清理临时文件
        rmdir /s /q "%INSTALL_DIR%temp" >nul 2>&1
    ) else (
        echo [警告] NSSM 下载失败，请手动安装 NSSM
        echo 你可以从 https://nssm.cc/download 下载 NSSM
    )
) else (
    echo [成功] NSSM 已安装
)
echo.

:: 检查服务是否已存在
sc query %SERVICE_NAME% >nul 2>&1
if %errorLevel% equ 0 (
    echo [信息] 服务已存在，正在停止并删除旧服务...
    nssm stop %SERVICE_NAME% >nul 2>&1
    timeout /t 2 >nul
    nssm remove %SERVICE_NAME% confirm >nul 2>&1
    timeout /t 2 >nul
)

:: 创建启动脚本
echo [创建] 正在创建启动脚本...
(
echo @echo off
echo cd /d "%INSTALL_DIR%"
echo "%PYTHON_EXE%" app.py
echo pause
) > "%INSTALL_DIR%run.bat"

:: 安装服务
echo [安装] 正在安装 Windows 服务...
nssm install %SERVICE_NAME% "%PYTHON_EXE%" "app.py"
if %errorLevel% neq 0 (
    echo [错误] 服务安装失败
    pause
    exit /b 1
)

:: 配置服务
nssm set %SERVICE_NAME% AppDirectory "%INSTALL_DIR%"
nssm set %SERVICE_NAME% DisplayName "%SERVICE_DISPLAY_NAME%"
nssm set %SERVICE_NAME% Description "%SERVICE_DESCRIPTION%"
nssm set %SERVICE_NAME% Start SERVICE_AUTO_START
nssm set %SERVICE_NAME% AppStdout "%INSTALL_DIR%service.log"
nssm set %SERVICE_NAME% AppStderr "%INSTALL_DIR%error.log"
nssm set %SERVICE_NAME% AppRotateFiles 1
nssm set %SERVICE_NAME% AppRotateBytes 1048576

echo [成功] Windows 服务安装完成
echo.

:: 询问是否启动服务
echo.
set /p START_SERVICE="是否立即启动服务？(Y/N): "
if /i "%START_SERVICE%"=="Y" (
    echo [启动] 正在启动服务...
    nssm start %SERVICE_NAME%
    timeout /t 3 >nul
    
    :: 检查服务状态
    sc query %SERVICE_NAME% | find "RUNNING" >nul
    if %errorLevel% equ 0 (
        echo [成功] 服务已启动
    ) else (
        echo [警告] 服务可能未成功启动，请检查日志
    )
)

echo.
echo ============================================
echo   安装完成！
echo ============================================
echo.
echo 服务名称: %SERVICE_NAME%
echo 显示名称: %SERVICE_DISPLAY_NAME%
echo.
echo 管理命令:
echo   启动服务: nssm start %SERVICE_NAME%
echo   停止服务: nssm stop %SERVICE_NAME%
echo   重启服务: nssm restart %SERVICE_NAME%
echo   删除服务: nssm remove %SERVICE_NAME% confirm
echo.
echo Web 界面: http://localhost:5000
echo.
echo 请在浏览器中打开上述地址进行配置
echo.
pause