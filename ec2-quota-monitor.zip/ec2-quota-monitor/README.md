# EC2 Quota Monitor

AWS EC2 配额监控服务 - 自动监控 EC2 配额变化并发送邮件通知

## 功能特点

- 🔄 **定时监控**: 每 10 分钟自动检查 EC2 配额（可自定义间隔）
- 📧 **邮件通知**: 配额变化时自动发送邮件通知
- 🌐 **Web 界面**: 简洁美观的 Web 管理界面
- 🔒 **安全存储**: AWS 凭证加密存储
- 🖥️ **Windows 服务**: 可安装为 Windows 服务，开机自启动

## 系统要求

- Windows 10/11 或 Windows Server 2016+
- Python 3.8+
- 网络连接（访问 AWS API 和邮件服务）

## 快速开始

### 方式一：直接运行

1. **安装依赖**
   ```bash
   cd ec2-quota-monitor
   pip install -r requirements.txt
   ```

2. **启动服务**
   ```bash
   python app.py
   ```

3. **打开浏览器**
   访问 http://localhost:5000

### 方式二：安装为 Windows 服务

1. **以管理员身份运行**
   右键点击 `install_service.bat`，选择"以管理员身份运行"

2. **按照提示完成安装**

3. **打开浏览器配置**
   访问 http://localhost:5000

## 使用说明

### 1. 配置 AWS 凭证

在 Web 界面中输入：
- **AWS Access Key**: AWS 访问密钥
- **AWS Secret Key**: AWS 密钥
- **AWS Region**: 要监控的区域

### 2. 配置通知邮箱

输入接收通知的邮箱地址

### 3. 测试连接

- 点击"测试 AWS"验证 AWS 凭证
- 点击"测试邮件"验证邮件发送

### 4. 启动监控

点击"启动监控"开始自动监控

## 项目结构

```
ec2-quota-monitor/
├── app.py              # Flask 主应用
├── config.py           # 配置管理
├── aws_service.py      # AWS EC2 Quota 查询
├── email_service.py    # 邮件发送服务
├── scheduler.py        # 定时任务调度
├── requirements.txt    # Python 依赖
├── install_service.bat # Windows 服务安装脚本
├── run.bat            # 启动脚本
├── templates/
│   └── index.html     # Web 界面
└── data/
    ├── config.json    # 配置存储
    └── quotas_history.json  # 配额历史
```

## API 接口

| 接口 | 方法 | 说明 |
|------|------|------|
| `/api/config` | GET/POST | 获取/更新配置 |
| `/api/test-aws` | POST | 测试 AWS 连接 |
| `/api/test-email` | POST | 测试邮件发送 |
| `/api/quotas` | GET | 获取当前配额 |
| `/api/status` | GET | 获取监控状态 |
| `/api/monitor/start` | POST | 启动监控 |
| `/api/monitor/stop` | POST | 停止监控 |
| `/api/monitor/check` | POST | 手动触发检查 |
| `/api/regions` | GET | 获取 AWS 区域列表 |

## Windows 服务管理

```bash
# 启动服务
nssm start EC2QuotaMonitor

# 停止服务
nssm stop EC2QuotaMonitor

# 重启服务
nssm restart EC2QuotaMonitor

# 删除服务
nssm remove EC2QuotaMonitor confirm
```

## 日志文件

- `ec2_quota_monitor.log` - 应用日志
- `service.log` - 服务输出日志
- `error.log` - 错误日志

## 安全说明

- AWS 凭证使用 Fernet 对称加密存储
- 加密密钥存储在 `data/.key` 文件中
- 请妥善保管该密钥文件

## 常见问题

### Q: 为什么无法连接 AWS？
A: 请检查：
1. AWS 凭证是否正确
2. IAM 用户是否有 `service-quotas:ListServiceQuotas` 权限
3. 网络是否可以访问 AWS API

### Q: 为什么邮件发送失败？
A: 请检查：
1. Pingram API Key 是否有效
2. 收件人邮箱地址是否正确
3. 网络是否可以访问邮件 API

### Q: 如何修改检查间隔？
A: 在 Web 界面中修改"检查间隔"字段，单位为分钟

## 许可证

MIT License