"""
Flask Web 应用
提供 Web 界面和 API 接口
"""
import os
import logging
from datetime import datetime
from flask import Flask, render_template, request, jsonify

from config import config
from aws_service import EC2QuotaService, format_quotas_for_display
from email_service import email_service
from scheduler import quota_monitor

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('ec2_quota_monitor.log', encoding='utf-8')
    ]
)
logger = logging.getLogger(__name__)

# 创建 Flask 应用
app = Flask(__name__)
app.secret_key = os.urandom(24)


# ==================== 页面路由 ====================

@app.route('/')
def index():
    """主页"""
    return render_template('index.html', config=config.to_dict())


# ==================== API 路由 ====================

@app.route('/api/config', methods=['GET'])
def get_config():
    """获取当前配置"""
    return jsonify({
        "success": True,
        "config": config.to_dict(safe=True)
    })


@app.route('/api/config/aws', methods=['POST'])
def update_aws_config():
    """更新 AWS 凭证配置"""
    try:
        data = request.get_json()
        aws_access_key = data.get('aws_access_key', '').strip()
        aws_secret_key = data.get('aws_secret_key', '').strip()
        aws_region = data.get('aws_region', 'us-east-1').strip()
        check_interval = data.get('check_interval', 10)

        if not aws_access_key and not config.aws_access_key:
            return jsonify({"success": False, "error": "AWS Access Key 不能为空"})
        if not aws_secret_key and not config.aws_secret_key:
            return jsonify({"success": False, "error": "AWS Secret Key 不能为空"})

        if aws_access_key:
            config.aws_access_key = aws_access_key
        if aws_secret_key:
            config.aws_secret_key = aws_secret_key
        config.aws_region = aws_region
        config.check_interval = int(check_interval)
        if config.aws_access_key and config.aws_secret_key:
            config.set_configured(True)

        logger.info("AWS 配置已更新")
        return jsonify({"success": True, "message": "AWS 配置已保存"})
    except Exception as e:
        logger.error(f"更新 AWS 配置失败: {e}")
        return jsonify({"success": False, "error": str(e)})


@app.route('/api/config/email', methods=['POST'])
def update_email_config():
    """更新邮箱配置"""
    try:
        data = request.get_json()
        notification_email = data.get('notification_email', '').strip()

        if not notification_email:
            return jsonify({"success": False, "error": "通知邮箱不能为空"})

        config.notification_email = notification_email
        logger.info("邮箱配置已更新")
        return jsonify({"success": True, "message": "邮箱配置已保存"})
    except Exception as e:
        logger.error(f"更新邮箱配置失败: {e}")
        return jsonify({"success": False, "error": str(e)})


@app.route('/api/test-aws', methods=['POST'])
def test_aws():
    """测试 AWS 连接"""
    try:
        data = request.get_json()
        
        # 使用请求中的凭证或已保存的凭证
        access_key = data.get('aws_access_key') or config.aws_access_key
        secret_key = data.get('aws_secret_key') or config.aws_secret_key
        region = data.get('aws_region') or config.aws_region
        
        if not access_key or not secret_key:
            return jsonify({"success": False, "error": "请先配置 AWS 凭证"})
        
        aws_service = EC2QuotaService(
            access_key=access_key,
            secret_key=secret_key,
            region=region
        )
        
        success, message = aws_service.test_connection()
        
        return jsonify({
            "success": success,
            "message": message
        })
        
    except Exception as e:
        logger.error(f"测试 AWS 连接失败: {e}")
        return jsonify({"success": False, "error": str(e)})


@app.route('/api/test-email', methods=['POST'])
def test_email():
    """测试邮件发送"""
    try:
        data = request.get_json()
        
        email = data.get('notification_email') or config.notification_email
        
        if not email:
            return jsonify({"success": False, "error": "请先配置通知邮箱"})
        
        result = email_service.send_test_email(email)
        
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"测试邮件发送失败: {e}")
        return jsonify({"success": False, "error": str(e)})


@app.route('/api/quotas', methods=['GET'])
def get_quotas():
    """获取当前配额"""
    try:
        if not config.is_configured:
            return jsonify({"success": False, "error": "请先完成配置"})
        
        aws_service = EC2QuotaService(
            access_key=config.aws_access_key,
            secret_key=config.aws_secret_key,
            region=config.aws_region
        )
        
        quotas = aws_service.get_all_ec2_quotas()
        formatted = format_quotas_for_display(quotas)
        
        return jsonify({
            "success": True,
            "quotas": formatted,
            "region": config.aws_region,
            "count": len(formatted)
        })
        
    except Exception as e:
        logger.error(f"获取配额失败: {e}")
        return jsonify({"success": False, "error": str(e)})


@app.route('/api/status', methods=['GET'])
def get_status():
    """获取监控状态"""
    try:
        status = quota_monitor.get_status()
        return jsonify({
            "success": True,
            "status": status
        })
    except Exception as e:
        logger.error(f"获取状态失败: {e}")
        return jsonify({"success": False, "error": str(e)})


@app.route('/api/monitor/start', methods=['POST'])
def start_monitor():
    """启动监控"""
    try:
        if not config.is_configured:
            return jsonify({"success": False, "error": "请先完成配置"})
        
        quota_monitor.start()
        
        return jsonify({
            "success": True,
            "message": "监控已启动"
        })
        
    except Exception as e:
        logger.error(f"启动监控失败: {e}")
        return jsonify({"success": False, "error": str(e)})


@app.route('/api/monitor/stop', methods=['POST'])
def stop_monitor():
    """停止监控"""
    try:
        quota_monitor.stop()
        
        return jsonify({
            "success": True,
            "message": "监控已停止"
        })
        
    except Exception as e:
        logger.error(f"停止监控失败: {e}")
        return jsonify({"success": False, "error": str(e)})


@app.route('/api/monitor/check', methods=['POST'])
def trigger_check():
    """手动触发检查"""
    try:
        if not config.is_configured:
            return jsonify({"success": False, "error": "请先完成配置"})
        
        result = quota_monitor.trigger_check()
        
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"手动检查失败: {e}")
        return jsonify({"success": False, "error": str(e)})


@app.route('/api/regions', methods=['GET'])
def get_regions():
    """获取 AWS 区域列表"""
    regions = [
        {"value": "us-east-1", "label": "美国东部 (弗吉尼亚北部)"},
        {"value": "us-east-2", "label": "美国东部 (俄亥俄)"},
        {"value": "us-west-1", "label": "美国西部 (加利福尼亚北部)"},
        {"value": "us-west-2", "label": "美国西部 (俄勒冈)"},
        {"value": "ap-south-1", "label": "亚太地区 (孟买)"},
        {"value": "ap-northeast-1", "label": "亚太地区 (东京)"},
        {"value": "ap-northeast-2", "label": "亚太地区 (首尔)"},
        {"value": "ap-northeast-3", "label": "亚太地区 (大阪)"},
        {"value": "ap-southeast-1", "label": "亚太地区 (新加坡)"},
        {"value": "ap-southeast-2", "label": "亚太地区 (悉尼)"},
        {"value": "ca-central-1", "label": "加拿大 (中部)"},
        {"value": "eu-central-1", "label": "欧洲 (法兰克福)"},
        {"value": "eu-west-1", "label": "欧洲 (爱尔兰)"},
        {"value": "eu-west-2", "label": "欧洲 (伦敦)"},
        {"value": "eu-west-3", "label": "欧洲 (巴黎)"},
        {"value": "eu-north-1", "label": "欧洲 (斯德哥尔摩)"},
        {"value": "sa-east-1", "label": "南美洲 (圣保罗)"},
    ]
    return jsonify({
        "success": True,
        "regions": regions
    })


# ==================== 错误处理 ====================

@app.errorhandler(404)
def not_found(error):
    return jsonify({"success": False, "error": "资源未找到"}), 404


@app.errorhandler(500)
def internal_error(error):
    return jsonify({"success": False, "error": "服务器内部错误"}), 500


# ==================== 启动应用 ====================

def create_app():
    """创建应用"""
    # 确保数据目录存在
    from pathlib import Path
    data_dir = Path(__file__).parent / "data"
    data_dir.mkdir(exist_ok=True)
    
    return app


if __name__ == '__main__':
    # 开发模式
    app = create_app()
    
    # 如果已配置，自动启动监控
    if config.is_configured:
        quota_monitor.start()
    
    # 启动 Flask 开发服务器
    app.run(host='0.0.0.0', port=5000, debug=False)