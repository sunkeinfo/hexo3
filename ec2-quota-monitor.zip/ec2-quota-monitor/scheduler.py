"""
定时任务调度器
负责定时检查 EC2 配额并发送通知
"""
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Any

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.interval import IntervalTrigger
from apscheduler.events import EVENT_JOB_ERROR, EVENT_JOB_EXECUTED

from config import config, QUOTAS_HISTORY_FILE
from aws_service import EC2QuotaService, compare_quotas
from email_service import email_service

logger = logging.getLogger(__name__)


class QuotaMonitor:
    """配额监控器"""
    
    def __init__(self):
        self.scheduler = BackgroundScheduler()
        self.last_check_time: Optional[datetime] = None
        self.last_quotas: Dict[str, Any] = {}
        self.is_running = False
        self.last_error: Optional[str] = None
        self.check_count = 0
        
        # 加载历史配额
        self._load_last_quotas()
        
        # 设置调度器事件监听
        self.scheduler.add_listener(self._job_executed, EVENT_JOB_EXECUTED)
        self.scheduler.add_listener(self._job_error, EVENT_JOB_ERROR)
    
    def _load_last_quotas(self):
        """加载上次的配额记录"""
        if QUOTAS_HISTORY_FILE.exists():
            try:
                with open(QUOTAS_HISTORY_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    from aws_service import get_monitored_quotas_map
                    all_quotas = data.get("quotas", {})
                    self.last_quotas = {k: v for k, v in all_quotas.items() if k in get_monitored_quotas_map()}
                    last_time_str = data.get("last_check_time")
                    if last_time_str:
                        self.last_check_time = datetime.fromisoformat(last_time_str)
                    logger.info(f"加载历史配额记录: {len(self.last_quotas)} 条")
            except Exception as e:
                logger.error(f"加载历史配额失败: {e}")
                self.last_quotas = {}
    
    def _save_quotas(self, quotas: Dict[str, Any]):
        """保存配额记录"""
        try:
            data = {
                "quotas": quotas,
                "last_check_time": datetime.now().isoformat(),
                "check_count": self.check_count
            }
            with open(QUOTAS_HISTORY_FILE, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            logger.info(f"保存配额记录: {len(quotas)} 条")
        except Exception as e:
            logger.error(f"保存配额记录失败: {e}")
    
    def _job_executed(self, event):
        """任务执行成功回调"""
        logger.info(f"配额检查任务执行成功")
    
    def _job_error(self, event):
        """任务执行失败回调"""
        self.last_error = str(event.exception)
        logger.error(f"配额检查任务执行失败: {event.exception}")
    
    def check_quotas(self):
        """检查配额的核心方法"""
        logger.info("开始检查 EC2 配额...")
        self.check_count += 1
        self.last_check_time = datetime.now()
        self.last_error = None
        
        try:
            # 检查配置是否完整
            if not config.is_configured:
                logger.warning("配置未完成，跳过检查")
                return
            
            # 创建 AWS 服务实例
            aws_service = EC2QuotaService(
                access_key=config.aws_access_key,
                secret_key=config.aws_secret_key,
                region=config.aws_region
            )
            
            # 获取当前配额
            current_quotas = aws_service.get_all_ec2_quotas()
            logger.info(f"获取到 {len(current_quotas)} 个配额")
            
            # 如果有历史记录，比较变化
            if self.last_quotas:
                changes = compare_quotas(self.last_quotas, current_quotas)
                
                if changes:
                    logger.info(f"检测到 {len(changes)} 个变化")
                    
                    # 发送通知
                    try:
                        result = email_service.send_quota_change_notification(
                            to_email=config.notification_email,
                            changes=changes,
                            region=config.aws_region,
                            old_quotas=self.last_quotas,
                            new_quotas=current_quotas
                        )
                        if result.get("success"):
                            logger.info("变化通知邮件发送成功")
                        else:
                            logger.error(f"变化通知邮件发送失败: {result.get('error')}")
                    except Exception as e:
                        logger.error(f"发送通知失败: {e}")
                else:
                    logger.info("没有检测到配额变化")
            
            # 更新历史记录
            self.last_quotas = current_quotas
            self._save_quotas(current_quotas)
            
        except Exception as e:
            self.last_error = str(e)
            logger.error(f"检查配额时发生错误: {e}")
    
    def start(self):
        """启动监控"""
        if self.is_running:
            logger.warning("监控已在运行中")
            return
        
        # 添加定时任务
        interval_minutes = config.check_interval
        self.scheduler.add_job(
            self.check_quotas,
            trigger=IntervalTrigger(minutes=interval_minutes),
            id='quota_check',
            name='EC2 Quota Check',
            replace_existing=True
        )
        
        # 启动调度器
        self.scheduler.start()
        self.is_running = True
        logger.info(f"配额监控已启动，检查间隔: {interval_minutes} 分钟")
        
        # 立即执行一次检查
        self.check_quotas()
    
    def stop(self):
        """停止监控"""
        if not self.is_running:
            return
        
        self.scheduler.shutdown(wait=False)
        self.is_running = False
        logger.info("配额监控已停止")
    
    def restart(self):
        """重启监控"""
        self.stop()
        self.start()
    
    def get_status(self) -> dict:
        """获取监控状态"""
        return {
            "is_running": self.is_running,
            "last_check_time": self.last_check_time.isoformat() if self.last_check_time else None,
            "check_count": self.check_count,
            "last_error": self.last_error,
            "interval_minutes": config.check_interval,
            "is_configured": config.is_configured,
            "quotas_count": len(self.last_quotas)
        }
    
    def trigger_check(self) -> dict:
        """手动触发一次检查"""
        try:
            self.check_quotas()
            return {"success": True, "message": "检查完成"}
        except Exception as e:
            return {"success": False, "error": str(e)}


# 全局监控器实例
quota_monitor = QuotaMonitor()