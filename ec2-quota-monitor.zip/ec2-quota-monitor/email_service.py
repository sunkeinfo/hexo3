"""
邮件发送模块
使用 Pingram API 发送通知邮件
"""
import logging
from typing import List
from datetime import datetime
import httpx

logger = logging.getLogger(__name__)


class EmailService:

    def send_email(self, to_email: str, subject: str, content: str) -> dict:
        from config import config
        try:
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {config.email_api_key}"
            }
            payload = {
                "type": config.email_notification_type,
                "to": {"email": to_email},
                "parameters": {"subject": subject, "comment": content},
                "templateId": config.email_template_id
            }
            with httpx.Client() as client:
                response = client.post(config.email_api_url, headers=headers, json=payload, timeout=30.0)
            if response.status_code in [200, 202]:
                logger.info(f"邮件发送成功: {to_email}")
                return {"success": True, "response": response.text}
            else:
                logger.error(f"邮件发送失败: HTTP {response.status_code} - {response.text}")
                return {"success": False, "error": f"HTTP {response.status_code}: {response.text}"}
        except Exception as e:
            logger.error(f"邮件发送失败: {e}")
            return {"success": False, "error": str(e)}
    
    def send_quota_change_notification(
        self,
        to_email: str,
        changes: List[dict],
        region: str,
        old_quotas: dict = None,
        new_quotas: dict = None
    ) -> dict:
        if not changes:
            logger.info("没有变化，跳过发送通知")
            return {"success": True, "message": "No changes to report"}

        subject = f"AWS EC2 Quota 变化通知 - {region}"

        content_lines = [
            f"AWS EC2 配额检测到变化",
            f"区域: {region}",
            f"时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            "",
            "=" * 50,
            "变化详情:",
            "=" * 50,
            ""
        ]

        for change in changes:
            change_type = change.get('type', 'unknown')
            name = change.get('name', 'Unknown')
            code = change.get('code', 'Unknown')

            if change_type == 'added':
                content_lines.append(f"✅ 新增配额: {name}")
                content_lines.append(f"   代码: {code}")
                content_lines.append(f"   上次检查: 无记录")
                content_lines.append(f"   本次检查: {change.get('new_value', 'N/A')}")
            elif change_type == 'removed':
                content_lines.append(f"❌ 删除配额: {name}")
                content_lines.append(f"   代码: {code}")
                content_lines.append(f"   上次检查: {change.get('old_value', 'N/A')}")
                content_lines.append(f"   本次检查: 已删除")
            elif change_type == 'changed':
                content_lines.append(f"🔄 配额变化: {name}")
                content_lines.append(f"   代码: {code}")
                content_lines.append(f"   上次检查: {change.get('old_value', 'N/A')}")
                content_lines.append(f"   本次检查: {change.get('new_value', 'N/A')}")
            elif change_type == 'usage_changed':
                content_lines.append(f"📊 使用量变化: {name}")
                content_lines.append(f"   代码: {code}")
                content_lines.append(f"   上次检查: {change.get('old_usage', 'N/A')}")
                content_lines.append(f"   本次检查: {change.get('new_usage', 'N/A')}")
                content_lines.append(f"   配额上限: {change.get('limit', 'N/A')}")
            content_lines.append("")

        # 添加所有配额的完整对比
        if old_quotas is not None and new_quotas is not None:
            content_lines.append("=" * 50)
            content_lines.append("所有监控配额对比:")
            content_lines.append("=" * 50)
            content_lines.append("")
            all_codes = set(list(old_quotas.keys()) + list(new_quotas.keys()))
            for code in sorted(all_codes):
                old_info = old_quotas.get(code)
                new_info = new_quotas.get(code)
                quota_name = (new_info or old_info or {}).get('name', code)
                old_val = old_info['value'] if old_info else '无记录'
                new_val = new_info['value'] if new_info else '已删除'
                content_lines.append(f"配额: {quota_name}")
                content_lines.append(f"   代码: {code}")
                content_lines.append(f"   上次检查: {old_val}")
                content_lines.append(f"   本次检查: {new_val}")
                content_lines.append("")

        content_lines.append("=" * 50)
        content_lines.append("此邮件由 EC2 Quota Monitor 自动发送")

        return self.send_email(to_email, subject, "\n".join(content_lines))
    
    def send_test_email(self, to_email: str) -> dict:
        """
        发送测试邮件
        
        Args:
            to_email: 收件人邮箱
            
        Returns:
            dict: 发送结果
        """
        subject = "EC2 Quota Monitor - 测试邮件"
        content = f"""
这是一封测试邮件。

EC2 Quota Monitor 服务已成功启动。

时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

如果您收到此邮件，说明邮件通知功能正常工作。
"""
        return self.send_email(to_email, subject, content)


# 全局邮件服务实例
email_service = EmailService()